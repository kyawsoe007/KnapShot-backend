'use strict';
module.exports = function (app) {

    var controller = require('../controllers/User');

    app.route('/user/sign-in')
        .post(controller.SignIn);

};




