'use strict';

const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const axios = require('axios');
const XLSX = require('xlsx');
const formidable = require('formidable');

//models
const db = require('../models/db');
const Company = require('../models/Company');
const CompanyItem = require('../models/CompanyItem');
const Personnel = require('../models/Personnel');
const Directory = require("../models/Directory");
const PersonnelItem = require("../models/PersonnelItem");

//util
const paginate = require('../utils/pagination');
const ThreeLevelIterator = require('../utils/ThreeLevelIterator');

//constants
const keyValues = require('../constants/keyValuesMap');
const keyValuesPair = require('../constants/keyValuesPair');

//config
const config = require('../../config');

const TechnologyArr = ['Advertising', 'Analytics and Tracking', 'Ecommerce', 'Widget', 'Hosting', 'Productivity']

function processBrand(obj, brand) {
    if (!obj[brand]) {
        obj[brand] = 1
    }
    obj[brand]++

    return obj
}

function filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter) {
    return COMP.map(x => {
        let { asset, directories } = x.dataValues
        directories = directories.filter(d => ["marketplace", "infoDirectory", "locationDirectory", "jobDirectory", "forum", "bloggers"].includes(d.directory))
        let dirObj = { default: 0 }
        for (let directory in directories) {
            if (!directories.hasOwnProperty(directory)) continue;
            let dirName = directories[directory].directory
            dirObj[dirName] = dirObj[dirName] ? dirObj[dirName] + 1 : 1
        }
        let totalMaxDir = Math.max(...Object.values(dirObj))
        let assets = JSON.parse(asset)


        let total = {}
        if (assets) for (var category in assets) {
            if (!assets.hasOwnProperty(category)) continue;
            if (!keyValues[category]) continue;

            var types = assets[category];
            for (var type in types) {
                if (!types.hasOwnProperty(type)) continue;
                if (!keyValues[category].includes(type)) continue;


                var brands = [...new Set(types[type])];
                for (var j = 0; j < brands.length; j++) {
                    var brand = brands[j];

                    total[category] = total[category] ? total[category] : {};

                    var total_type = total[category];
                    total_type[type] = total_type[type] ? total_type[type] : [];

                    total[category][type].push(brand)
                }
            }
        }

        let clone = assetDataProcess(total)

        // data change
        x.dataValues.asset = JSON.stringify(clone);
        x.dataValues.totalMaxDir = totalMaxDir;
        return x;

    }).filter(value => {
        let { asset } = value.dataValues
        let assets = JSON.parse(asset);

        if (assets && restrictTechnologyFilter && Object.keys(restrictTechnologyFilter).length) {

            let restrictTechnologyFilterIterator = ThreeLevelIterator(restrictTechnologyFilter)
            let pass = true;


            for (let row of restrictTechnologyFilterIterator) {
                let { f_key, s_key, t_key } = row;
                if (assets[f_key] && assets[f_key][s_key] && assets[f_key][s_key].includes(t_key)) {
                    pass = false;
                    break;
                }
            }
            return pass;
        }
        return true;
    }).filter(value => {
        let { asset } = value.dataValues
        let assets = JSON.parse(asset);


        if (assets && technologyFilter && Object.keys(technologyFilter).length) {

            let technologyFilterIterator = ThreeLevelIterator(technologyFilter)
            let pass = false;


            for (let row of technologyFilterIterator) {
                let { f_key, s_key, t_key } = row;
                if (assets[f_key] && assets[f_key][s_key] && assets[f_key][s_key].includes(t_key)) {
                    pass = true;
                    break;
                }
            }
            return pass;
        }
        return true;
    }).filter(row => {
        let { totalMaxDir } = row.dataValues
        // checkingTotal.push(totalMaxDir)
        if (digitalPresenceFilter && digitalPresenceFilter.directory) {
            let arr = digitalPresenceFilter.directory
            let numberArr = []
            for (let index in arr) {
                if (!arr.hasOwnProperty(index)) continue;


                if (arr[index] === '0 Presence') numberArr.push(0)
                else if (arr[index] === '1 - 2') numberArr.push(1, 2)
                else if (arr[index] === '3 - 5') numberArr.push(3, 4, 5)
                else if (arr[index] === '>6') for (var i = 6; i < 50; i++) numberArr.push(i)
                // else false
            }
            if (numberArr.includes(totalMaxDir)) return true
            else return false
        }
        return true
    });
}

function AssetDP(obj) {
    let clone = { ...obj }
    if (Object.keys(clone).length) {

        if (clone.Ecommerce && clone.Payment && Object.keys(clone.Ecommerce).length && Object.keys(clone.Payment).length) {
            clone.Ecommerce = {
                ...clone.Ecommerce,
                ...obj.Payment
            }
            delete clone.Payment
        }

        if (clone["Analytics and Tracking"]) {
            if (clone["Analytics and Tracking"]["CRM"] && Object.keys(clone["Analytics and Tracking"]["CRM"]).length) {
                clone.Productivity = {
                    ...clone.Productivity,
                    "CRM": { ...clone["Analytics and Tracking"]["CRM"] },
                }
                delete clone["Analytics and Tracking"]["CRM"]
            }

            if (clone["Analytics and Tracking"]["Lead Generation"] && Object.keys(clone["Analytics and Tracking"]["Lead Generation"]).length) {
                clone.Productivity = {
                    ...clone.Productivity,
                    "Lead Generation": { ...clone["Analytics and Tracking"]["Lead Generation"] },
                }
                delete clone["Analytics and Tracking"]["Lead Generation"]
            }

            if (clone["Analytics and Tracking"]["Product Recommendations"] && Object.keys(clone["Analytics and Tracking"]["Product Recommendations"]).length) {
                clone.Productivity = {
                    ...clone.Productivity,
                    "Product Recommendations": { ...clone["Analytics and Tracking"]["Product Recommendations"] },
                }
                delete clone["Analytics and Tracking"]["Product Recommendations"]
            }

            if (clone["Analytics and Tracking"]["Feedback Forms and Surveys"] && Object.keys(clone["Analytics and Tracking"]["Feedback Forms and Surveys"]).length) {
                clone.Productivity = {
                    ...clone.Productivity,
                    "Feedback Forms and Surveys": { ...clone["Analytics and Tracking"]["Feedback Forms and Surveys"] },
                }
                delete clone["Analytics and Tracking"]["Feedback Forms and Surveys"]
            }
        }

        if (clone["Email Hosting Providers"]) {
            if (clone["Email Hosting Providers"]["Campaign Management"] && Object.keys(clone["Email Hosting Providers"]["Campaign Management"]).length) {
                clone.Productivity = {
                    ...clone.Productivity,
                    "Campaign Management": { ...clone["Email Hosting Providers"]["Campaign Management"] },
                }
                delete clone["Email Hosting Providers"]["Campaign Management"]
            }
            if (clone["Email Hosting Providers"]["Business Email Hosting"] && Object.keys(clone["Email Hosting Providers"]["Business Email Hosting"]).length) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Business Email Hosting": { ...clone["Email Hosting Providers"]["Business Email Hosting"] },
                }
                delete clone["Email Hosting Providers"]["Business Email Hosting"]
            }
            if (clone["Email Hosting Providers"]["Web Hosting Provider Email"] && Object.keys(clone["Email Hosting Providers"]["Web Hosting Provider Email"]).length) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Web Hosting Provider Email": { ...clone["Email Hosting Providers"]["Web Hosting Provider Email"] },
                }
                delete clone["Email Hosting Providers"]["Web Hosting Provider Email"]
            }
            if (clone["Email Hosting Providers"]["Marketing Platform"] && Object.keys(clone["Email Hosting Providers"]["Marketing Platform"]).length) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Marketing Platform": { ...clone["Email Hosting Providers"]["Marketing Platform"] },
                }
                delete clone["Email Hosting Providers"]["Marketing Platform"]
            }
        }

        if (clone["Web Hosting Providers"]) {
            if (clone["Web Hosting Providers"]["Cloud PaaS"] && Object.keys(clone["Web Hosting Providers"]["Cloud PaaS"]).length) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Cloud PaaS": { ...clone["Web Hosting Providers"]["Cloud PaaS"] },
                }
                delete clone["Web Hosting Providers"]["Cloud PaaS"]
            }
            if (clone["Web Hosting Providers"]["Cloud Hosting"] && Object.keys(clone["Web Hosting Providers"]["Cloud Hosting"]).length) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Cloud Hosting": { ...clone["Web Hosting Providers"]["Cloud Hosting"] },
                }
                delete clone["Web Hosting Providers"]["Cloud Hosting"]
            }
            if (clone["Web Hosting Providers"]["Dedicated Hosting"] && Object.keys(clone["Web Hosting Providers"]["Dedicated Hosting"]).length) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Dedicated Hosting": { ...clone["Web Hosting Providers"]["Dedicated Hosting"] },
                }
                delete clone["Web Hosting Providers"]["Dedicated Hosting"]
            }
        }


        if (clone["Widgets"] && clone["Widgets"]["Marketing Automation"] && Object.keys(clone["Widgets"]["Marketing Automation"]).length) {
            clone.Productivity = {
                ...clone.Productivity,
                "Marketing Automation": { ...clone["Widgets"]["Marketing Automation"] },
            }
            delete clone["Widgets"]["Marketing Automation"]
        }
    }
    return clone
}

function assetDataProcess(obj) {
    let clone = { ...obj }
    if (Object.keys(clone).length) {

        if (clone.Ecommerce && clone.Payment) {
            clone.Ecommerce = {
                ...clone.Ecommerce,
                ...obj.Payment
            }
        }

        if (clone["Analytics and Tracking"]) {
            if (clone["Analytics and Tracking"]["CRM"]) {
                clone.Productivity = {
                    ...clone.Productivity,
                    "CRM": clone["Analytics and Tracking"]["CRM"],
                }
            }

            if (clone["Analytics and Tracking"]["Lead Generation"]) {
                clone.Productivity = {
                    ...clone.Productivity,
                    "Lead Generation": clone["Analytics and Tracking"]["Lead Generation"],
                }
            }

            if (clone["Analytics and Tracking"]["Product Recommendations"]) {
                clone.Productivity = {
                    ...clone.Productivity,
                    "Product Recommendations": clone["Analytics and Tracking"]["Product Recommendations"],
                }
            }

            if (clone["Analytics and Tracking"]["Feedback Forms and Surveys"]) {
                clone.Productivity = {
                    ...clone.Productivity,
                    "Feedback Forms and Surveys": clone["Analytics and Tracking"]["Feedback Forms and Surveys"],
                }
            }
        }

        if (clone["Email Hosting Providers"]) {
            if (clone["Email Hosting Providers"]["Campaign Management"]) {
                clone.Productivity = {
                    ...clone.Productivity,
                    "Campaign Management": clone["Email Hosting Providers"]["Campaign Management"],
                }
            }
            if (clone["Email Hosting Providers"]["Business Email Hosting"]) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Business Email Hosting": clone["Email Hosting Providers"]["Business Email Hosting"],
                }
            }
            if (clone["Email Hosting Providers"]["Web Hosting Provider Email"]) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Web Hosting Provider Email": clone["Email Hosting Providers"]["Web Hosting Provider Email"],
                }
            }
            if (clone["Email Hosting Providers"]["Marketing Platform"]) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Marketing Platform": clone["Email Hosting Providers"]["Marketing Platform"],
                }
            }
        }

        if (clone["Web Hosting Providers"]) {
            if (clone["Web Hosting Providers"]["Cloud PaaS"]) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Cloud PaaS": clone["Web Hosting Providers"]["Cloud PaaS"],
                }
            }
            if (clone["Web Hosting Providers"]["Cloud Hosting"]) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Cloud Hosting": clone["Web Hosting Providers"]["Cloud Hosting"],
                }
            }
            if (clone["Web Hosting Providers"]["Dedicated Hosting"]) {
                clone.Hosting = {
                    ...clone.Hosting,
                    "Dedicated Hosting": clone["Web Hosting Providers"]["Dedicated Hosting"],
                }
            }
        }


        if (clone["Widgets"] && clone["Widgets"]["Marketing Automation"]) {
            clone.Productivity = {
                ...clone.Productivity,
                "Marketing Automation": clone["Widgets"]["Marketing Automation"],
            }
        }
    }
    // if (clone) {
    //     const _return = { ...clone }
    //     // delete _return["Payment"]
    //     // delete _return["Analytics and Tracking"]["CRM"]
    //     // delete _return["Analytics and Tracking"]["Lead Generation"]
    //     // delete _return["Analytics and Tracking"]["Product Recommendations"]
    //     // delete _return["Analytics and Tracking"]["Feedback Forms and Surveys"]
    //     // delete _return["Email Hosting Providers"]["Campaign Management"]
    //     // delete _return["Email Hosting Providers"]["Business Email Hosting"]
    //     // delete _return["Email Hosting Providers"]["Web Hosting Provider Email"]
    //     // delete _return["Email Hosting Providers"]["Marketing Platform"]
    //     // delete _return["Web Hosting Providers"]["Cloud Paas"]
    //     // delete _return["Web Hosting Providers"]["Cloud Hosting"]
    //     // delete _return["Web Hosting Providers"]["Dedicated Hosting"]
    //     // delete _return["Widgets"]["Marketing Automation"]
    //     // return _return
    // }

    return clone
}

exports.totalDigitalEngagement = async function (req, res) {

    let file_name = req.body.file_name;
    let dataset = req.body.dataset;
    let frimographicFilter = req.body.frimographicFilter;
    let digitalPresenceFilter = req.body.digitalPresenceFilter;
    let technologyFilter = req.body.technologyFilter;
    let restrictTechnologyFilter = req.body.restrictTechnologyFilter
    const otherCompanyIds = req.body.otherCompanyIds
    let whereFilter = [{ dataset }];

    if (file_name !== "Master DB (Golden Source)") whereFilter.push({ file_name });

    frimographicFilter && frimographicFilter.industry && whereFilter.push({ industry: { [Op.or]: frimographicFilter.industry } })
    frimographicFilter && frimographicFilter.main_hq_location && whereFilter.push({ main_hq_location: { [Op.or]: frimographicFilter.main_hq_location } })
    frimographicFilter && frimographicFilter.emp_size && whereFilter.push({ total_personnel: { [Op.or]: frimographicFilter.emp_size } })
    frimographicFilter && frimographicFilter.total_personnel && whereFilter.push({ company_name: { [Op.or]: frimographicFilter.total_personnel } })

    if (digitalPresenceFilter && digitalPresenceFilter.websites) {
        if (digitalPresenceFilter.websites.indexOf('Has') > -1) digitalPresenceFilter.websites.push({ [Op.ne]: null })
        whereFilter.push({ website: { [Op.or]: digitalPresenceFilter.websites } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.email) {
        if (digitalPresenceFilter.email.indexOf('Has') > -1) digitalPresenceFilter.email.push({ [Op.ne]: null })
        whereFilter.push({ company_email_address: { [Op.or]: digitalPresenceFilter.email } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.phone) {
        if (digitalPresenceFilter.phone.indexOf('Has') > -1) digitalPresenceFilter.phone.push({ [Op.ne]: null })
        whereFilter.push({ main_line_number: { [Op.or]: digitalPresenceFilter.phone } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.twitter) {
        if (digitalPresenceFilter.twitter.indexOf('Has') > -1) digitalPresenceFilter.twitter.push({ [Op.ne]: null })
        whereFilter.push({ twitter: { [Op.or]: digitalPresenceFilter.twitter } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.linkedIn) {
        if (digitalPresenceFilter.linkedIn.indexOf('Has') > -1) digitalPresenceFilter.linkedIn.push({ [Op.ne]: null })
        whereFilter.push({ linkedIn: { [Op.or]: digitalPresenceFilter.linkedIn } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.instagram) {
        if (digitalPresenceFilter.instagram.indexOf('Has') > -1) digitalPresenceFilter.instagram.push({ [Op.ne]: null })
        whereFilter.push({ instagram: { [Op.or]: digitalPresenceFilter.instagram } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.facebook) {
        if (digitalPresenceFilter.facebook.indexOf('Has') > -1) digitalPresenceFilter.facebook.push({ [Op.ne]: null })
        whereFilter.push({ facebook: { [Op.or]: digitalPresenceFilter.facebook } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.address) {
        if (digitalPresenceFilter.address.indexOf('Has') > -1) digitalPresenceFilter.address.push({ [Op.ne]: null })
        whereFilter.push({ address: { [Op.or]: digitalPresenceFilter.address } })
    }
    // if (digitalPresenceFilter && digitalPresenceFilter.directory) {
    //     if (digitalPresenceFilter.directory.indexOf('0 Presence') > -1) digitalPresenceFilter.directory.push({ [Op.eq]: -1 })
    //     if (digitalPresenceFilter.directory.indexOf('intermediate') > -1) digitalPresenceFilter.directory.push({ [Op.and]: [{ [Op.gte]: 2 }, { [Op.lt]: 5 }] })
    //     if (digitalPresenceFilter.directory.indexOf('high') > -1) digitalPresenceFilter.directory.push({ [Op.and]: [{ [Op.gte]: 5 }, { [Op.lt]: 8 }] })
    //     if (digitalPresenceFilter.directory.indexOf('advance') > -1) digitalPresenceFilter.directory.push({ [Op.gte]: 8 })
    //     whereFilter.push({ no_of_directory_presence: { [Op.or]: digitalPresenceFilter.directory } })
    // }
    if (digitalPresenceFilter && digitalPresenceFilter.digital) {
        if (digitalPresenceFilter.digital.indexOf('Basic') > -1) digitalPresenceFilter.digital.push({ [Op.lt]: 2 })
        if (digitalPresenceFilter.digital.indexOf('Intermediate') > -1) digitalPresenceFilter.digital.push({ [Op.and]: [{ [Op.gte]: 2 }, { [Op.lt]: 5 }] })
        if (digitalPresenceFilter.digital.indexOf('High') > -1) digitalPresenceFilter.digital.push({ [Op.and]: [{ [Op.gte]: 5 }, { [Op.lt]: 8 }] })
        if (digitalPresenceFilter.digital.indexOf('Advance') > -1) digitalPresenceFilter.digital.push({ [Op.gte]: 8 })
        whereFilter.push({ overall_knapshot_score: { [Op.or]: digitalPresenceFilter.digital } })
    }
    let results = [], totalArr = [], mainData = [], otherCompanies = []

    try {
        const companies = await Company.findAll({
            where: {
                [Op.and]: whereFilter
            },
            attributes: ["id", "asset", "industry", "overall_knapshot_score"],
            include: [
                { model: Directory }
            ]
        }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter))
        // .then(COMP => {
        //     return COMP.map(x => {
        //         let { asset } = x.dataValues
        //         let assets = JSON.parse(asset)


        //         let total = {}
        //         if (assets) for (var category in assets) {
        //             if (!assets.hasOwnProperty(category)) continue;
        //             if (!keyValues[category]) continue;

        //             var types = assets[category];
        //             for (var type in types) {
        //                 if (!types.hasOwnProperty(type)) continue;
        //                 if (!keyValues[category].includes(type)) continue;


        //                 var brands = [...new Set(types[type])];
        //                 for (var j = 0; j < brands.length; j++) {
        //                     var brand = brands[j];

        //                     total[category] = total[category] ? total[category] : {};

        //                     var total_type = total[category];
        //                     total_type[type] = total_type[type] ? total_type[type] : [];

        //                     total[category][type].push(brand)
        //                 }
        //             }
        //         }
        //         totalArr.push(total)

        //         // data change
        //         x.dataValues.asset = JSON.stringify(total);
        //         return x;

        //     })
        // }).filter(value => {
        //     let assets = JSON.parse(value.dataValues.asset);

        //     if (!(technologyFilter && Object.keys(technologyFilter).length)) return true
        //     if (assets) {
        //         var technologyFilterIterator = ThreeLevelIterator(technologyFilter);
        //         var pass = false;
        //         for (var row of technologyFilterIterator) {
        //             var { f_key, s_key, t_key } = row;
        //             if (assets[f_key] && assets[f_key][s_key] && assets[f_key][s_key].includes(t_key)) {
        //                 pass = true;
        //                 break;
        //             }
        //         }
        //         return pass;
        //     }
        //     return false;
        // });

        let basic = 0;
        let intermediate = 0;
        let high = 0;
        let advance = 0;

        if (technologyFilter && otherCompanyIds) {
            otherCompanies = await Company.findAll({
                where: { id: { [Op.or]: otherCompanyIds } },
                attributes: ["id", "asset", "industry", "overall_knapshot_score"],
                include: [
                    { model: Directory }
                ],
            }).then(COMP => {
                return COMP.map(x => {
                    let { directories } = x.dataValues
                    directories = directories.filter(d => ["marketplace", "infoDirectory", "locationDirectory", "jobDirectory", "forum", "bloggers"].includes(d.directory))
                    let dirObj = { default: 0 }
                    for (let directory in directories) {
                        if (!directories.hasOwnProperty(directory)) continue;
                        let dirName = directories[directory].directory
                        dirObj[dirName] = dirObj[dirName] ? dirObj[dirName] + 1 : 1
                    }
                    let totalMaxDir = Math.max(...Object.values(dirObj))

                    // data change
                    x.dataValues.totalMaxDir = totalMaxDir;
                    return x;

                }).filter(row => {
                    let { totalMaxDir } = row.dataValues
                    if (digitalPresenceFilter && digitalPresenceFilter.directory) {
                        let arr = digitalPresenceFilter.directory
                        let numberArr = []
                        for (let index in arr) {
                            if (!arr.hasOwnProperty(index)) continue;

                            if (arr[index] === '0 Presence') numberArr.push(0)
                            else if (arr[index] === '1 - 2') numberArr.push(1, 2)
                            else if (arr[index] === '3 - 5') numberArr.push(3, 4, 5)
                            else if (arr[index] === '>6') for (var i = 6; i < 50; i++) numberArr.push(i)
                        }
                        if (numberArr.includes(totalMaxDir)) return true
                        else return false
                    }
                    return true
                });
            })
        }
        mainData = [...companies, ...otherCompanies]

        console.log("check data", mainData.length, companies.length, otherCompanies.length)

        if (mainData) {
            for (let i = 0; i < mainData.length; i++) {
                let score = mainData[i].overall_knapshot_score;

                if (score < 2) basic += 1;
                if (score >= 2 && score < 5) intermediate += 1;
                if (score >= 5 && score < 8) high += 1;
                if (score >= 8) advance += 1;
            }
        }

        results.push(
            { label: "Basic", count: basic },
            { label: "Intermediate", count: intermediate },
            { label: "High", count: high },
            { label: "Advanced", count: advance },
        );

        return res.status(200).json({
            message: "Successful",
            data: results,
            count: mainData.length
        });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.industryBreakDown = async function (req, res) {

    const datasetName = req.body.dataset;
    const industryNames = req.body.industries;
    const digitalNames = req.body.digitals;
    const fileName = req.body.file_name;
    let technologyFilter = req.body.technologyFilter;
    let restrictTechnologyFilter = req.body.restrictTechnologyFilter
    let digitalPresenceFilter = req.body.digitalPresenceFilter;


    let totalIndustries = [];
    let results = [];


    try {
        for (let i = 0; i < industryNames.length; i++) {

            let obj = {
                label: industryNames[i],
                count: 0,
                basic: 0,
                intermediate: 0,
                high: 0,
                advanced: 0
            };

            let industryQuery = [
                { industry: industryNames[i] },
                { dataset: datasetName }
            ];
            let basicQuery = [
                { overall_knapshot_score: { [Op.lt]: 2 } },
                { dataset: datasetName },
                { industry: industryNames[i] }
            ];
            let intermediateQuery = [
                { overall_knapshot_score: { [Op.gte]: 2 } },
                { overall_knapshot_score: { [Op.lt]: 5 } },
                { industry: industryNames[i] },
                { dataset: datasetName }
            ];
            let highQuery = [
                { overall_knapshot_score: { [Op.gte]: 5 } },
                { overall_knapshot_score: { [Op.lt]: 8 } },
                { industry: industryNames[i] },
                { dataset: datasetName }
            ];
            let advancedQuery = [
                { overall_knapshot_score: { [Op.gte]: 8 } },
                { industry: industryNames[i] },
                { dataset: datasetName },
            ];

            if (fileName !== "Master DB (Golden Source)") {
                industryQuery.push({ file_name: fileName });
                basicQuery.push({ file_name: fileName });
                intermediateQuery.push({ file_name: fileName });
                highQuery.push({ file_name: fileName });
                advancedQuery.push({ file_name: fileName });
            }

            let industries = await CompanyItem.findAll({
                where: { [Op.and]: industryQuery },
                // attributes: ["id", "asset", "industry"],
                include: [
                    { model: Directory }
                ]
            }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter));

            if (industries) {

                totalIndustries.push({ name: industryNames[i], count: industries.length });
                obj.count = industries.length;

                if (digitalNames.indexOf("Basic") >= 0) {
                    let basic = await Company.findAll({
                        where: { [Op.and]: basicQuery },
                        include: [
                            { model: Directory }
                        ]
                    }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter));
                    obj.basic = basic.length;
                }

                if (digitalNames.indexOf("Intermediate") >= 0) {
                    let intermediate = await Company.findAll({
                        where: { [Op.and]: intermediateQuery },
                        include: [
                            { model: Directory }
                        ]
                    }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter));
                    obj.intermediate = intermediate.length;
                }

                if (digitalNames.indexOf("High") >= 0) {
                    let high = await Company.findAll({
                        where: { [Op.and]: highQuery },
                        include: [
                            { model: Directory }
                        ]
                    }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter));
                    obj.high = high.length;
                }

                if (digitalNames.indexOf("Advanced") >= 0) {
                    let advance = await Company.findAll({
                        where: { [Op.and]: advancedQuery },
                        include: [
                            { model: Directory }
                        ]
                    }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter));
                    obj.advanced = advance.length;
                }

                // if (digitalNames.indexOf("Basic") >= 0) {
                //     let basic = await CompanyItem.count({ where: { [Op.and]: basicQuery } });
                //     obj.basic = basic;
                // }

                // if (digitalNames.indexOf("Intermediate") >= 0) {
                //     let intermediate = await CompanyItem.count({ where: { [Op.and]: intermediateQuery } });
                //     obj.intermediate = intermediate;
                // }

                // if (digitalNames.indexOf("High") >= 0) {
                //     let high = await CompanyItem.count({ where: { [Op.and]: highQuery } });
                //     obj.high = high;
                // }

                // if (digitalNames.indexOf("Advanced") >= 0) {
                //     let advance = await CompanyItem.count({ where: { [Op.and]: advancedQuery } });
                //     obj.advanced = advance;
                // }

                results.push(obj);
            }
        }

        return res.status(200).json({
            message: "Successful",
            results: results,
            totalIndustries: totalIndustries
        });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.getDigitalPresentByCountry = async function (req, res) {

    const dataset = req.body.datasets;
    const filename = req.body.fileName;

    let results = {};

    let types = [
        {
            type: "Basic",
            query: {
                overall_knapshot_score: {
                    [Op.lt]: 2
                }
            }
        },
        {
            type: "Intermediate",
            query: {
                overall_knapshot_score: {
                    [Op.gte]: 2
                },
                overall_knapshot_score: {
                    [Op.lt]: 5
                },
            }
        },
        {
            type: "High",
            query: {
                overall_knapshot_score: {
                    [Op.gte]: 5
                },
                overall_knapshot_score: {
                    [Op.lt]: 8
                },
            }
        },
        {
            type: "Advanced",
            query: {
                overall_knapshot_score: {
                    [Op.gte]: 8
                },
            }
        }
    ];

    if (filename !== "Master DB (Golden Source)") {
        types.map(t => {
            t["query"] = { ...t["query"], file_name: filename };
        });
    }

    try {
        for (let j = 0; j < types.length; j++) {

            const count = await CompanyItem.count({
                where: {
                    [Op.and]: [
                        {
                            dataset: dataset
                        },
                        types[j].query
                    ]
                }
            });

            const noUrl_noDirPsc_noSocial = await CompanyItem.count({
                where: {
                    [Op.and]: [
                        {
                            dataset: dataset
                        },
                        {
                            website: {
                                [Op.eq]: null
                            }
                        },
                        {
                            no_of_directory_presence: {
                                [Op.lte]: 0
                            }
                        },
                        {
                            [Op.and]: [
                                {
                                    facebook: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    linkedIn: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    twitter: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    instagram: {
                                        [Op.eq]: null
                                    }
                                }
                            ]
                        },
                        types[j].query
                    ]
                }
            });

            const noUrl_hasDirPsc_noSocial = await CompanyItem.count({
                where: {
                    [Op.and]: [
                        {
                            dataset: dataset
                        },
                        {
                            website: {
                                [Op.eq]: null
                            }
                        },
                        {
                            no_of_directory_presence: {
                                [Op.gt]: 0
                            }
                        },
                        {
                            [Op.and]: [
                                {
                                    facebook: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    linkedIn: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    twitter: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    instagram: {
                                        [Op.eq]: null
                                    }
                                }
                            ]
                        },
                        types[j].query
                    ]
                }
            });

            const noUrl_hasDirPsc_hasSocial = await CompanyItem.count({
                where: {
                    [Op.and]: [
                        {
                            dataset: dataset
                        },
                        {
                            website: {
                                [Op.eq]: null
                            }
                        },
                        {
                            no_of_directory_presence: {
                                [Op.gt]: 0
                            }
                        },
                        {
                            [Op.or]: [
                                {
                                    facebook: {
                                        [Op.ne]: null
                                    }
                                },
                                {
                                    linkedIn: {
                                        [Op.ne]: null
                                    }
                                },
                                {
                                    twitter: {
                                        [Op.ne]: null
                                    }
                                },
                                {
                                    instagram: {
                                        [Op.ne]: null
                                    }
                                }
                            ]
                        },
                        types[j].query
                    ]
                }
            });

            const hasUrl_noDirPsc_noSocial = await CompanyItem.count({
                where: {
                    [Op.and]: [
                        {
                            dataset: dataset
                        },
                        {
                            website: {
                                [Op.ne]: null
                            }
                        },
                        {
                            no_of_directory_presence: {
                                [Op.lte]: 0
                            }
                        },
                        {
                            [Op.or]: [
                                {
                                    facebook: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    linkedIn: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    twitter: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    instagram: {
                                        [Op.eq]: null
                                    }
                                }
                            ]
                        },
                        types[j].query
                    ]
                }
            });

            const hasUrl_hasDirPsc_noSocial = await CompanyItem.count({
                where: {
                    [Op.and]: [
                        {
                            dataset: dataset
                        },
                        {
                            website: {
                                [Op.ne]: null
                            }
                        },
                        {
                            no_of_directory_presence: {
                                [Op.gt]: 0
                            }
                        },
                        {
                            [Op.and]: [
                                {
                                    facebook: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    linkedIn: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    twitter: {
                                        [Op.eq]: null
                                    }
                                },
                                {
                                    instagram: {
                                        [Op.eq]: null
                                    }
                                }
                            ]
                        },
                        types[j].query
                    ]
                }
            });

            const hasUrl_hasDirPsc_hasSocial = await CompanyItem.count({
                where: {
                    [Op.and]: [
                        {
                            dataset: dataset
                        },
                        {
                            website: {
                                [Op.ne]: null
                            }
                        },
                        {
                            no_of_directory_presence: {
                                [Op.gt]: 0
                            }
                        },
                        {
                            [Op.or]: [
                                {
                                    facebook: {
                                        [Op.ne]: null
                                    }
                                },
                                {
                                    linkedIn: {
                                        [Op.ne]: null
                                    }
                                },
                                {
                                    twitter: {
                                        [Op.ne]: null
                                    }
                                },
                                {
                                    instagram: {
                                        [Op.ne]: null
                                    }
                                }
                            ]
                        },
                        types[j].query
                    ]
                }
            });

            results[types[j]["type"]] = [
                types[j]["type"],
                count,
                noUrl_noDirPsc_noSocial,
                noUrl_hasDirPsc_noSocial,
                noUrl_hasDirPsc_hasSocial,
                hasUrl_noDirPsc_noSocial,
                hasUrl_hasDirPsc_noSocial,
                hasUrl_hasDirPsc_hasSocial
            ];
        }
        return res.status(200).json({ message: 'Successful', results: results });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
}

exports.totalIndustry = async function (req, res) {

    let dataset = req.body.dataset;
    let file_name = req.body.file_name;

    let industryName = [];
    let totalIndustry = 0;
    let industries;

    try {
        if (file_name !== "Master DB (Golden Source)") {
            industries = await db.query(
                `SELECT IF(industry IS NULL OR industry = '', 'Not Available', industry) industry, COUNT(1) as count FROM company WHERE dataset IN(:datasets) and file_name LIKE :file_name GROUP BY 1 ORDER BY count DESC`,
                {
                    replacements: { datasets: dataset, file_name: file_name },
                    type: db.QueryTypes.SELECT
                }
            );
        } else {
            industries = await db.query(
                `SELECT IF(industry IS NULL OR industry = '', 'Not Available', industry) industry, COUNT(1) as count FROM company WHERE dataset IN(:datasets) GROUP BY 1 ORDER BY count DESC`,
                {
                    replacements: { datasets: dataset },
                    type: db.QueryTypes.SELECT
                }
            );
        }

        for (let i = 0; i < industries.length; i++) {
            industryName.push(industries[i].industry);
            totalIndustry += industries[i].count
        }

        return res.status(200).json({
            message: "Successful",
            results: {
                industries: industries,
                totalIndustry: totalIndustry,
                industryName: industryName
            }
        });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.totalCountry = async function (req, res) {

    let filename = req.body.file_name;

    let countries = [];
    let countryName = [];
    let totalCountry = 0;

    try {

        if (filename !== "Master DB (Golden Source)") {
            countries = await db.query(
                `SELECT dataset, COUNT(1) as count FROM company WHERE file_name LIKE :filename GROUP BY dataset ORDER BY count DESC`,
                {
                    replacements: { filename: filename },
                    type: db.QueryTypes.SELECT
                }
            );
        } else {
            countries = await db.query(
                `SELECT dataset, COUNT(1) as count FROM company GROUP BY dataset ORDER BY count DESC`,
                {
                    type: db.QueryTypes.SELECT
                }
            );
        }

        for (let i = 0; i < countries.length; i++) {
            countryName.push(countries[i].dataset);
            totalCountry += countries[i].count;
        }

        return res.status(200).json({
            message: "Successful",
            results: {
                country: countries,
                totalCountry: totalCountry,
                countryName: countryName
            }
        });

    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.totalPersonnel = async function (req, res) {

    let dataset = req.body.dataset;
    let file_name = req.body.file_name;


    let personnelName = [];
    let totalPersonnel = 0;
    let personnel;

    try {
        if (file_name !== "Master DB (Golden Source)") {
            personnel = await db.query(
                `SELECT IF(total_Personnel IS NULL OR total_Personnel = '' OR total_Personnel = '-1', 'Not Available', total_Personnel) total_Personnel, COUNT(1) as count FROM company WHERE dataset IN(:datasets) and file_name LIKE :file_name GROUP BY 1 ORDER BY count DESC`,
                {
                    replacements: { datasets: dataset, file_name: file_name },
                    type: db.QueryTypes.SELECT
                }
            );
        } else {
            personnel = await db.query(
                `SELECT IF(total_Personnel IS NULL OR total_Personnel = '', 'Not Available', total_Personnel) total_Personnel, COUNT(1) as count FROM company WHERE dataset IN(:datasets) GROUP BY 1 ORDER BY count DESC`,
                {
                    replacements: { datasets: dataset },
                    type: db.QueryTypes.SELECT
                }
            );
        }

        for (let i = 0; i < personnel.length; i++) {

            personnelName.push(personnel[i].total_Personnel);
            totalPersonnel += personnel[i].count
        }

        return res.status(200).json({
            message: "Successful",
            results: {
                personnel: personnel,
                totalPersonnel: totalPersonnel,
                personnelName: personnelName
            }
        });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.totalCompanyStaff = async function (req, res) {

    let dataset = req.body.dataset;
    let file_name = req.body.file_name;


    let personnelName = [];
    let totalPersonnel = 0;
    let personnel;

    let whereFilter = [{ dataset }];
    let CompData = [{ label: "Company with Staff", count: 0, company_name: [] }, { label: "Company without Staff", count: 0, company_name: [] }]

    if (file_name !== "Master DB (Golden Source)") whereFilter.push({ file_name });

    try {
        const personnel = await Company.findAll({
            where: {
                [Op.and]: whereFilter
            },
            attributes: ["company_name"],
            include: [
                { model: PersonnelItem }
            ]
        }).then(COMP => {
            COMP.map(x => {
                const { company_name, personnels } = x.dataValues
                if (personnels.length > 0) {
                    CompData[0].count += 1
                    CompData[0].company_name.push(company_name)
                }
                else {
                    CompData[1].count += 1
                    CompData[1].company_name.push(company_name)
                }
            })
        })

        for (let i = 0; i < CompData.length; i++) {

            personnelName.push(CompData[i].label);
            totalPersonnel += CompData[i].count
        }

        return res.status(200).json({
            message: "Successful",
            results: {
                personnel: CompData,
                totalPersonnel: totalPersonnel,
                personnelName: personnelName
            }
        });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.totalHQLocation = async function (req, res) {

    let dataset = req.body.dataset;
    let file_name = req.body.file_name;


    let HQLocationName = [];
    let totalHQLocation = 0;
    let HQLocation;

    try {
        if (file_name !== "Master DB (Golden Source)") {
            HQLocation = await db.query(
                `SELECT IF(main_hq_location IS NULL OR main_hq_location = '', 'Not Available', main_hq_location) main_hq_location, COUNT(1) as count FROM company WHERE dataset IN(:datasets) and file_name LIKE :file_name GROUP BY 1 ORDER BY count DESC`,
                {
                    replacements: { datasets: dataset, file_name: file_name },
                    type: db.QueryTypes.SELECT
                }
            );
        } else {
            HQLocation = await db.query(
                `SELECT IF(main_hq_location IS NULL OR main_hq_location = '', 'Not Available', main_hq_location) main_hq_location, COUNT(1) as count FROM company WHERE dataset IN(:datasets) GROUP BY 1 ORDER BY count DESC`,
                {
                    replacements: { datasets: dataset },
                    type: db.QueryTypes.SELECT
                }
            );
        }

        for (let i = 0; i < HQLocation.length; i++) {
            HQLocationName.push(HQLocation[i].main_hq_location);
            totalHQLocation += HQLocation[i].count
        }


        return res.status(200).json({
            message: "Successful",
            results: {
                HQLocation: HQLocation,
                totalHQLocation: totalHQLocation,
                HQLocationName: HQLocationName
            }
        });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.getEndUserTechnology = async function (req, res) {

    const datasets = req.body.datasets;
    const filename = req.body.fileName;

    let technologies = [
        "All Technology",
        "Advertising",
        "Analytics and Tracking",
        "Ecommerce",
        "Payment",
        "Widgets"
    ];

    let data = {
        "All Technology": [],
        "Advertising": [],
        "Analytics and Tracking": [],
        "Ecommerce": [],
        "Payment": [],
        "Widgets": []
    };

    let header = {
        "Advertising": ["Country", "Total Company", "Ad Network", "ads txt", "Contextual Advertising", "Ad Exchange", "Facebook Exchange", "Retargeting / Remarketing"],
        "Analytics and Tracking": ["Country", "Total Company", "Conversion Optimization", "Tag Management", "Advertiser Tracking", "Audience Measurement", "Lead Generation", "Marketing Automation"],
        "Ecommerce": ["Country", "Total Company", "Non Platform", "Hosted Solution", "Open Source", "Multi-Channel", "Enterprise", "SMB Solution"],
        "Payment": ["Country", "Total Company", "Payments Processor", "Payment Acceptance", "Payment Currency", "Checkout Buttons", "PP, PA, PC, CO", "PA & PC CO"],
        "Widgets": ["Country", "Total Company", "Live Chat", "Customer Login", "Social Sharing", "Schedule Management", "Ticketing System", "Bookings"],
        "All Technology": ["Country", "Total Company", "Advertising", "SEO", "Analytics", "E-commerce", "Payments", "Widgets"]
    }

    try {
        for (let i = 0; i < datasets.length; i++) {

            let companies;

            if (filename !== "Master DB (Golden Source)") {
                companies = await CompanyItem.findAll({
                    attributes: ["asset"],
                    where: {
                        [Op.and]: [
                            { dataset: datasets[i] },
                            {
                                asset: {
                                    [Op.ne]: null
                                }
                            },
                            {
                                filename: fileName
                            }
                        ]
                    }
                });
            } else {
                companies = await CompanyItem.findAll({
                    attributes: ["asset"],
                    where: {
                        [Op.and]: [
                            { dataset: datasets[i] },
                            {
                                asset: {
                                    [Op.ne]: null
                                }
                            }
                        ]
                    }
                });
            }

            let adNetwork = 0;
            let adsTxt = 0;
            let contextualAds = 0;
            let adExchange = 0;
            let fbExchange = 0;
            let retargetingAds = 0;

            let conversionOpt = 0;
            let tagMng = 0;
            let adsTracking = 0;
            let audienceMeasurement = 0;
            let leadGeneration = 0;
            let marketAutomation = 0;

            let nonPlatform = 0;
            let hostedSolution = 0;
            let openSource = 0;
            let multiChannel = 0;
            let enterprise = 0;
            let smbSolution = 0;

            let payProcessor = 0;
            let payAcceptance = 0;
            let payCurrency = 0;
            let checkOurButton = 0;
            let PPPAPCCO = 0;
            let PAPCCO = 0;

            let liveChat = 0;
            let customerLogin = 0;
            let socialSharing = 0;
            let scheduleManagement = 0;
            let ticketingSystem = 0;
            let bookings = 0;

            let totalAdvertisingCount = 0;
            let totalSEOCount = 0;
            let totalAnalyticsCount = 0;
            let totalEcommerceCount = 0;
            let totalPaymentCount = 0;
            let totalWidgetsCount = 0;

            for (let j = 0; j < companies.length; j++) {

                let jsonObj = JSON.parse(companies[j]["asset"]);

                if (jsonObj !== null) {

                    if (jsonObj["Advertising"] !== undefined) {
                        totalAdvertisingCount += 1;
                        if (jsonObj["Advertising"]["Ad Network"] !== undefined) adNetwork += 1;
                        if (jsonObj["Advertising"]["ads txt"] !== undefined) adsTxt += 1;
                        if (jsonObj["Advertising"]["Contextual Advertising"] !== undefined) contextualAds += 1;
                        if (jsonObj["Advertising"]["Ad Exchange"] !== undefined) adExchange += 1;
                        if (jsonObj["Advertising"]["Facebook Exchange"] !== undefined) fbExchange += 1;
                        if (jsonObj["Advertising"]["Retargeting / Remarketing"] !== undefined) retargetingAds += 1;
                    }

                    if (jsonObj["Analytics and Tracking"] !== undefined) {
                        totalAnalyticsCount += 1;
                        if (jsonObj["Analytics and Tracking"]["Conversion Optimization"] !== undefined) conversionOpt += 1;
                        if (jsonObj["Analytics and Tracking"]["Tag Management"] !== undefined) tagMng += 1;
                        if (jsonObj["Analytics and Tracking"]["Advertiser Tracking"] !== undefined) adsTracking += 1;
                        if (jsonObj["Analytics and Tracking"]["Audience Measurement"] !== undefined) audienceMeasurement += 1;
                        if (jsonObj["Analytics and Tracking"]["Lead Generation"] !== undefined) leadGeneration += 1;
                        if (jsonObj["Analytics and Tracking"]["Marketing Automation"] !== undefined) marketAutomation += 1;
                    }

                    if (jsonObj["Ecommerce"] !== undefined) {
                        totalEcommerceCount += 1;
                        if (jsonObj["Ecommerce"]["Non Platform"] !== undefined) nonPlatform += 1;
                        if (jsonObj["Ecommerce"]["Hosted Solution"] !== undefined) hostedSolution += 1;
                        if (jsonObj["Ecommerce"]["Open Source"] !== undefined) openSource += 1;
                        if (jsonObj["Ecommerce"]["Multi-Channel"] !== undefined) multiChannel += 1;
                        if (jsonObj["Ecommerce"]["Enterprise"] !== undefined) enterprise += 1;
                        if (jsonObj["Ecommerce"]["SMB Solution"] !== undefined) smbSolution += 1;
                    }

                    if (jsonObj["Payment"] !== undefined) {
                        totalPaymentCount += 1;
                        if (jsonObj["Payment"]["Payments Processor"] !== undefined) payProcessor += 1;
                        if (jsonObj["Payment"]["Payment Acceptance"] !== undefined) payAcceptance += 1;
                        if (jsonObj["Payment"]["Payment Currency"] !== undefined) payCurrency += 1;
                        if (jsonObj["Payment"]["Checkout Buttons"] !== undefined) checkOurButton += 1;

                        if (jsonObj["Payment"]["Payment Acceptance"] !== undefined &&
                            jsonObj["Payment"]["Payment Currency"] !== undefined &&
                            jsonObj["Payment"]["Checkout Buttons"] !== undefined
                        ) {
                            PAPCCO += 1;
                        }

                        if (jsonObj["Payment"]["Payments Processor"] !== undefined &&
                            jsonObj["Payment"]["Payment Acceptance"] !== undefined &&
                            jsonObj["Payment"]["Payment Currency"] !== undefined &&
                            jsonObj["Payment"]["Checkout Buttons"] !== undefined
                        ) {
                            PPPAPCCO += 1;
                        }

                    }

                    if (jsonObj["Widgets"] !== undefined) {
                        totalWidgetsCount += 1;
                        if (jsonObj["Widgets"]["Live Chat"] !== undefined) liveChat += 1;
                        if (jsonObj["Widgets"]["Login"] !== undefined) customerLogin += 1;
                        if (jsonObj["Widgets"]["Social Sharing"] !== undefined) socialSharing += 1;
                        if (jsonObj["Widgets"]["Schedule Management"] !== undefined) scheduleManagement += 1;
                        if (jsonObj["Widgets"]["Ticketing System"] !== undefined) ticketingSystem += 1;
                        if (jsonObj["Widgets"]["Bookings"] !== undefined) bookings += 1;
                    }
                }
            }

            let adsObj = {};
            adsObj["Total Company"] = totalAdvertisingCount;
            adsObj["Country"] = datasets[i];
            adsObj["Ad Network"] = isNaN(Math.round((adNetwork / totalAdvertisingCount) * 100)) ? 0 : Math.round((adNetwork / totalAdvertisingCount) * 100);
            adsObj["ads txt"] = isNaN(Math.round((adsTxt / totalAdvertisingCount) * 100)) ? 0 : Math.round((adsTxt / totalAdvertisingCount) * 100);
            adsObj["Contextual Advertising"] = isNaN(Math.round((contextualAds / totalAdvertisingCount) * 100)) ? 0 : Math.round((contextualAds / totalAdvertisingCount) * 100);
            adsObj["Ad Exchange"] = isNaN(Math.round((adExchange / totalAdvertisingCount) * 100)) ? 0 : Math.round((adExchange / totalAdvertisingCount) * 100);
            adsObj["Facebook Exchange"] = isNaN(Math.round((fbExchange / totalAdvertisingCount) * 100)) ? 0 : Math.round((fbExchange / totalAdvertisingCount) * 100);
            adsObj["Retargeting / Remarketing"] = isNaN(Math.round((retargetingAds / totalAdvertisingCount) * 100)) ? 0 : Math.round((retargetingAds / totalAdvertisingCount) * 100);

            let analyticAndTrackingObj = {};
            analyticAndTrackingObj["Total Company"] = totalAnalyticsCount;
            analyticAndTrackingObj["Country"] = datasets[i];
            analyticAndTrackingObj["Conversion Optimization"] = isNaN(Math.round((conversionOpt / totalAnalyticsCount) * 100)) ? 0 : Math.round((conversionOpt / totalAnalyticsCount) * 100);
            analyticAndTrackingObj["Tag Management"] = isNaN(Math.round((tagMng / totalAnalyticsCount) * 100)) ? 0 : Math.round((tagMng / totalAnalyticsCount) * 100);
            analyticAndTrackingObj["Advertiser Tracking"] = isNaN(Math.round((adsTracking / totalAnalyticsCount) * 100)) ? 0 : Math.round((adsTracking / totalAnalyticsCount) * 100);
            analyticAndTrackingObj["Audience Measurement"] = isNaN(Math.round((audienceMeasurement / totalAnalyticsCount) * 100)) ? 0 : Math.round((audienceMeasurement / totalAnalyticsCount) * 100);
            analyticAndTrackingObj["Lead Generation"] = isNaN(Math.round((leadGeneration / totalAnalyticsCount) * 100)) ? 0 : Math.round((leadGeneration / totalAnalyticsCount) * 100);
            analyticAndTrackingObj["Marketing Automation"] = isNaN(Math.round((marketAutomation / totalAnalyticsCount) * 100)) ? 0 : Math.round((marketAutomation / totalAnalyticsCount) * 100);

            let ecommerceObj = {};
            ecommerceObj["Total Company"] = totalEcommerceCount;
            ecommerceObj["Country"] = datasets[i];
            ecommerceObj["Non Platform"] = isNaN(Math.round((nonPlatform / totalEcommerceCount) * 100)) ? 0 : Math.round((nonPlatform / totalEcommerceCount) * 100);
            ecommerceObj["Hosted Solution"] = isNaN(Math.round((hostedSolution / totalEcommerceCount) * 100)) ? 0 : Math.round((hostedSolution / totalEcommerceCount) * 100);
            ecommerceObj["Open Source"] = isNaN(Math.round((openSource / totalEcommerceCount) * 100)) ? 0 : Math.round((openSource / totalEcommerceCount) * 100);
            ecommerceObj["Multi-Channel"] = isNaN(Math.round((multiChannel / totalEcommerceCount) * 100)) ? 0 : Math.round((multiChannel / totalEcommerceCount) * 100);
            ecommerceObj["Enterprise"] = isNaN(Math.round((enterprise / totalEcommerceCount) * 100)) ? 0 : Math.round((enterprise / totalEcommerceCount) * 100);
            ecommerceObj["SMB Solution"] = isNaN(Math.round((smbSolution / totalEcommerceCount) * 100)) ? 0 : Math.round((smbSolution / totalEcommerceCount) * 100);

            let paymentObj = {};
            paymentObj["Total Company"] = totalPaymentCount;
            paymentObj["Country"] = datasets[i];
            paymentObj["Payments Processor"] = isNaN(Math.round((payProcessor / totalPaymentCount) * 100)) ? 0 : Math.round((payProcessor / totalPaymentCount) * 100);
            paymentObj["Payment Acceptance"] = isNaN(Math.round((payAcceptance / totalPaymentCount) * 100)) ? 0 : Math.round((payAcceptance / totalPaymentCount) * 100);
            paymentObj["Payment Currency"] = isNaN(Math.round((payCurrency / totalPaymentCount) * 100)) ? 0 : Math.round((payCurrency / totalPaymentCount) * 100);
            paymentObj["Checkout Buttons"] = isNaN(Math.round((checkOurButton / totalPaymentCount) * 100)) ? 0 : Math.round((checkOurButton / totalPaymentCount) * 100);
            paymentObj["PP, PA, PC, CO"] = isNaN(Math.round((PPPAPCCO / totalPaymentCount) * 100)) ? 0 : Math.round((PPPAPCCO / totalPaymentCount) * 100);
            paymentObj["PA & PC CO"] = isNaN(Math.round((PAPCCO / totalPaymentCount) * 100)) ? 0 : Math.round((PAPCCO / totalPaymentCount) * 100);

            let widgetsObj = {};
            widgetsObj["Total Company"] = totalWidgetsCount;
            widgetsObj["Country"] = datasets[i];
            widgetsObj["Live Chat"] = isNaN(Math.round((liveChat / totalWidgetsCount) * 100)) ? 0 : Math.round((liveChat / totalWidgetsCount) * 100);
            widgetsObj["Customer Login"] = isNaN(Math.round((customerLogin / totalWidgetsCount) * 100)) ? 0 : Math.round((customerLogin / totalWidgetsCount) * 100);
            widgetsObj["Social Sharing"] = isNaN(Math.round((socialSharing / totalWidgetsCount) * 100)) ? 0 : Math.round((socialSharing / totalWidgetsCount) * 100);
            widgetsObj["Schedule Management"] = isNaN(Math.round((scheduleManagement / totalWidgetsCount) * 100)) ? 0 : Math.round((scheduleManagement / totalWidgetsCount) * 100);
            widgetsObj["Ticketing System"] = isNaN(Math.round((ticketingSystem / totalWidgetsCount) * 100)) ? 0 : Math.round((ticketingSystem / totalWidgetsCount) * 100);
            widgetsObj["Bookings"] = isNaN(Math.round((bookings / totalWidgetsCount) * 100)) ? 0 : Math.round((bookings / totalWidgetsCount) * 100);

            let allTechnologyObj = {};
            allTechnologyObj["Total Company"] = companies.length;
            allTechnologyObj["Country"] = datasets[i];
            allTechnologyObj["Advertising"] = isNaN(Math.round((totalAdvertisingCount / companies.length) * 100)) ? 0 : Math.round((totalAdvertisingCount / companies.length) * 100);
            allTechnologyObj["SEO"] = 0;
            allTechnologyObj["Analytics"] = isNaN(Math.round((totalAnalyticsCount / companies.length) * 100)) ? 0 : Math.round((totalAnalyticsCount / companies.length) * 100);
            allTechnologyObj["E-commerce"] = isNaN(Math.round((totalEcommerceCount / companies.length) * 100)) ? 0 : Math.round((totalEcommerceCount / companies.length) * 100);
            allTechnologyObj["Payments"] = isNaN(Math.round((totalPaymentCount / companies.length) * 100)) ? 0 : Math.round((totalPaymentCount / companies.length) * 100);
            allTechnologyObj["Widgets"] = isNaN(Math.round((totalWidgetsCount / companies.length) * 100)) ? 0 : Math.round((totalWidgetsCount / companies.length) * 100);

            data["All Technology"].push(allTechnologyObj);
            data["Advertising"].push(adsObj);
            data["Analytics and Tracking"].push(analyticAndTrackingObj);
            data["Ecommerce"].push(ecommerceObj);
            data["Payment"].push(paymentObj);
            data["Widgets"].push(widgetsObj);
        }

        return res.status(200).json({
            message: "Successful",
            results: data,
            technologies: technologies,
            header: header
        });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.getProviderTechnology = async function (req, res) {

    const datasets = req.body.datasets;
    const filename = req.body.fileName;

    let results = [];

    let types = ["Advertising", "Analytics and Tracking", "Ecommerce", "Payment", "Widgets"];

    let headers = [...datasets];

    const categoryTypes = {
        "Advertising": [
            // "Avertising  Network",
            "ads txt",
            // "Ad Exchange",
            "Audience Targeting",
            // "Facebook Exchange",
            // "Ad Server",
            // "Affiliate Programs",
            "Contextual Advertising",
            "Dynamic Creative Optimization",
            "Digital Video Ads",
            "Retargeting / Remarketing",
            // "Header Bidding"
        ],
        "Analytics and Tracking":
            [
                "Application Performance",
                // "A/B Testing",
                // "Ad Analytics",
                "Conversion Optimization",
                "Advertiser Tracking",
                "Tag Management",
                "Audience Measurement",
                "Visitor Count Tracking"
            ],
        "Ecommerce":
            [
                "Non Platform",
                "Hosted Solution",
                "Open Source",
                "Checkout Buttons",
                "Payment Acceptance",
                "Payments Processor",
                // "Payment Currency"
            ],
        "Widget":
            [
                "Live Chat",
                "Login",
                "Ticketing System",
                "Bookings",
                "Social Sharing",
                "Social Management"
            ],
        "Hosting":
            [
                "Cloud Hosting",
                "Cloud PaaS",
                "Dedicated Hosting",
                "Business Email Hosting",
                "Web Hosting Provider Email",
                "Marketing Platform",
            ],
        "Productivity":
            [
                "CRM",
                "Lead Generation",
                "Marketing Automation",
                "Product Recommendations",
                "Feedback Forms and Surveys",
                "Campaign Management"
            ]
    };

    let total = {
        "Advertising": {},
        "Analytics and Tracking": {},
        "Ecommerce": {},
        "Payment": {},
        "Widgets": {}
    }

    try {
        for (let i = 0; i < datasets.length; i++) {

            let data = {
                "Advertising": {
                    "ads txt": {},
                    "Audience Targeting": {},
                    "Contextual Advertising": {},
                    "Dynamic Creative Optimization": {},
                    "Digital Video Ads": {},
                    "Retargeting / Remarketing": {},
                },
                "Analytics and Tracking": {
                    "Application Performance": {},
                    "Conversion Optimization": {},
                    "Advertiser Tracking": {},
                    "Tag Management": {},
                    "Audience Measurement": {},
                    "Visitor Count Tracking": {},
                },
                "Ecommerce": {
                    "Non Platform": {},
                    "Hosted Solution": {},
                    "Open Source": {},
                    "Checkout Buttons": {},
                    "Payment Acceptance": {},
                    "Payments Processor": {},
                },
                "Hosting": {
                    "Cloud Hosting": {},
                    "Cloud PaaS": {},
                    "Dedicated Hostig": {},
                    "Business Email Hosting": {},
                    "Web Hosting Provider Email": {},
                    "Marketing Platform": {},
                },
                "Widgets": {
                    "Live Chat": {},
                    "Login": {},
                    "Ticketing System": {},
                    "Bookings": {},
                    "Social Sharing": {},
                    "Social Management": {},
                },
                "Productivity": {
                    "CRM": {},
                    "Lead Generation": {},
                    "Marketing Automation": {},
                    "Product Recommendations": {},
                    "Feedback Forms and Surveys": {},
                    "Campaign Management": {},
                }
            };

            let companies;
            if (filename !== "Master DB (Golden Source)") {
                companies = await CompanyItem.findAll({
                    attributes: ["asset"],
                    where: {
                        [Op.and]: [
                            { dataset: datasets[i] },
                            {
                                asset: {
                                    [Op.ne]: null
                                }
                            },
                            {
                                file_name: filename
                            }
                        ]
                    }
                });
            } else {
                companies = await CompanyItem.findAll({
                    attributes: ["asset"],
                    where: {
                        [Op.and]: [
                            { dataset: datasets[i] },
                            {
                                asset: {
                                    [Op.ne]: null
                                }
                            }
                        ]
                    }
                });
            }

            for (let j = 0; j < companies.length; j++) {

                let jsonObj = JSON.parse(companies[j]["asset"]);

                if (jsonObj["Advertising"] !== undefined) {
                    if (total["Advertising"][datasets[i]] === undefined) {
                        total["Advertising"][datasets[i]] = { count: 1 };
                    } else {
                        total["Advertising"][datasets[i]]["count"] += 1;
                    }
                    if (jsonObj["Advertising"]["Ad Network"] !== undefined) {
                        (jsonObj["Advertising"]["Ad Network"]).map(a => {
                            if (data["Advertising"]["Ad Network"][a] === undefined) {
                                data["Advertising"]["Ad Network"][a] = { "name": a, "count": 0 };
                            }
                            data["Advertising"]["Ad Network"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Advertising"]["ads txt"] !== undefined) {
                        (jsonObj["Advertising"]["ads txt"]).map(a => {
                            if (data["Advertising"]["ads txt"][a] === undefined) {
                                data["Advertising"]["ads txt"][a] = { "name": a, "count": 0 };
                            }
                            data["Advertising"]["ads txt"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Advertising"]["Contextual Advertising"] !== undefined) {
                        (jsonObj["Advertising"]["Contextual Advertising"]).map(a => {
                            if (data["Advertising"]["Contextual Advertising"][a] === undefined) {
                                data["Advertising"]["Contextual Advertising"][a] = { "name": a, "count": 0 };
                            }
                            data["Advertising"]["Contextual Advertising"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Advertising"]["Ad Exchange"] !== undefined) {
                        (jsonObj["Advertising"]["Ad Exchange"]).map(a => {
                            if (data["Advertising"]["Ad Exchange"][a] === undefined) {
                                data["Advertising"]["Ad Exchange"][a] = { "name": a, "count": 0 };
                            }
                            data["Advertising"]["Ad Exchange"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Advertising"]["Facebook Exchange"] !== undefined) {
                        (jsonObj["Advertising"]["Facebook Exchange"]).map(a => {
                            if (data["Advertising"]["Facebook Exchange"][a] === undefined) {
                                data["Advertising"]["Facebook Exchange"][a] = { "name": a, "count": 0 };
                            }
                            data["Advertising"]["Facebook Exchange"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Advertising"]["Retargeting / Remarketing"] !== undefined) {
                        (jsonObj["Advertising"]["Retargeting / Remarketing"]).map(a => {
                            if (data["Advertising"]["Retargeting / Remarketing"][a] === undefined) {
                                data["Advertising"]["Retargeting / Remarketing"][a] = { "name": a, "count": 0 };
                            }
                            data["Advertising"]["Retargeting / Remarketing"][a]["count"] += 1;
                        });
                    }
                }

                if (jsonObj["Analytics and Tracking"] !== undefined) {
                    if (total["Analytics and Tracking"][datasets[i]] === undefined) {
                        total["Analytics and Tracking"][datasets[i]] = { count: 1 };
                    } else {
                        total["Analytics and Tracking"][datasets[i]]["count"] += 1;
                    }
                    if (jsonObj["Analytics and Tracking"]["Conversion Optimization"] !== undefined) {
                        (jsonObj["Analytics and Tracking"]["Conversion Optimization"]).map(a => {
                            if (data["Analytics and Tracking"]["Conversion Optimization"][a] === undefined) {
                                data["Analytics and Tracking"]["Conversion Optimization"][a] = { "name": a, "count": 0 };
                            }
                            data["Analytics and Tracking"]["Conversion Optimization"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Analytics and Tracking"]["Tag Management"] !== undefined) {
                        (jsonObj["Analytics and Tracking"]["Tag Management"]).map(a => {
                            if (data["Analytics and Tracking"]["Tag Management"][a] === undefined) {
                                data["Analytics and Tracking"]["Tag Management"][a] = { "name": a, "count": 0 };
                            }
                            data["Analytics and Tracking"]["Tag Management"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Analytics and Tracking"]["Advertiser Tracking"] !== undefined) {
                        (jsonObj["Analytics and Tracking"]["Advertiser Tracking"]).map(a => {
                            if (data["Analytics and Tracking"]["Advertiser Tracking"][a] === undefined) {
                                data["Analytics and Tracking"]["Advertiser Tracking"][a] = { "name": a, "count": 0 };
                            }
                            data["Analytics and Tracking"]["Advertiser Tracking"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Analytics and Tracking"]["Audience Measurement"] !== undefined) {
                        (jsonObj["Analytics and Tracking"]["Audience Measurement"]).map(a => {
                            if (data["Analytics and Tracking"]["Audience Measurement"][a] === undefined) {
                                data["Analytics and Tracking"]["Audience Measurement"][a] = { "name": a, "count": 0 };
                            }
                            data["Analytics and Tracking"]["Audience Measurement"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Analytics and Tracking"]["Lead Generation"] !== undefined) {
                        (jsonObj["Analytics and Tracking"]["Lead Generation"]).map(a => {
                            if (data["Analytics and Tracking"]["Lead Generation"][a] === undefined) {
                                data["Analytics and Tracking"]["Lead Generation"][a] = { "name": a, "count": 0 };
                            }
                            data["Analytics and Tracking"]["Lead Generation"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Analytics and Tracking"]["Marketing Automation"] !== undefined) {
                        (jsonObj["Analytics and Tracking"]["Marketing Automation"]).map(a => {
                            if (data["Analytics and Tracking"]["Marketing Automation"][a] === undefined) {
                                data["Analytics and Tracking"]["Marketing Automation"][a] = { "name": a, "count": 0 };
                            }
                            data["Analytics and Tracking"]["Marketing Automation"][a]["count"] += 1;
                        });
                    }
                }

                if (jsonObj["Ecommerce"] !== undefined) {
                    if (total["Ecommerce"][datasets[i]] === undefined) {
                        total["Ecommerce"][datasets[i]] = { count: 1 };
                    } else {
                        total["Ecommerce"][datasets[i]]["count"] += 1;
                    }
                    if (jsonObj["Ecommerce"]["Non Platform"] !== undefined) {
                        (jsonObj["Ecommerce"]["Non Platform"]).map(a => {
                            if (data["Ecommerce"]["Non Platform"][a] === undefined) {
                                data["Ecommerce"]["Non Platform"][a] = { "name": a, "count": 0 };
                            }
                            data["Ecommerce"]["Non Platform"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Ecommerce"]["Hosted Solution"] !== undefined) {
                        (jsonObj["Ecommerce"]["Hosted Solution"]).map(a => {
                            if (data["Ecommerce"]["Hosted Solution"][a] === undefined) {
                                data["Ecommerce"]["Hosted Solution"][a] = { "name": a, "count": 0 };
                            }
                            data["Ecommerce"]["Hosted Solution"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Ecommerce"]["Open Source"] !== undefined) {
                        (jsonObj["Ecommerce"]["Open Source"]).map(a => {
                            if (data["Ecommerce"]["Open Source"][a] === undefined) {
                                data["Ecommerce"]["Open Source"][a] = { "name": a, "count": 0 };
                            }
                            data["Ecommerce"]["Open Source"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Ecommerce"]["Multi-Channel"] !== undefined) {
                        (jsonObj["Ecommerce"]["Multi-Channel"]).map(a => {
                            if (data["Ecommerce"]["Multi-Channel"][a] === undefined) {
                                data["Ecommerce"]["Multi-Channel"][a] = { "name": a, "count": 0 };
                            }
                            data["Ecommerce"]["Multi-Channel"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Ecommerce"]["Enterprise"] !== undefined) {
                        (jsonObj["Ecommerce"]["Enterprise"]).map(a => {
                            if (data["Ecommerce"]["Enterprise"][a] === undefined) {
                                data["Ecommerce"]["Enterprise"][a] = { "name": a, "count": 0 };
                            }
                            data["Ecommerce"]["Enterprise"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Ecommerce"]["SMB Solution"] !== undefined) {
                        (jsonObj["Ecommerce"]["SMB Solution"]).map(a => {
                            if (data["Ecommerce"]["SMB Solution"][a] === undefined) {
                                data["Ecommerce"]["SMB Solution"][a] = { "name": a, "count": 0 };
                            }
                            data["Ecommerce"]["SMB Solution"][a]["count"] += 1;
                        });
                    }
                }

                if (jsonObj["Payment"] !== undefined) {
                    if (total["Payment"][datasets[i]] === undefined) {
                        total["Payment"][datasets[i]] = { count: 1 };
                    } else {
                        total["Payment"][datasets[i]]["count"] += 1;
                    }
                    if (jsonObj["Payment"]["Payments Processor"] !== undefined) {
                        (jsonObj["Payment"]["Payments Processor"]).map(a => {
                            if (data["Payment"]["Payments Processor"][a] === undefined) {
                                data["Payment"]["Payments Processor"][a] = { "name": a, "count": 0 };
                            }
                            data["Payment"]["Payments Processor"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Payment"]["Payment Acceptance"] !== undefined) {
                        (jsonObj["Payment"]["Payment Acceptance"]).map(a => {
                            if (data["Payment"]["Payment Acceptance"][a] === undefined) {
                                data["Payment"]["Payment Acceptance"][a] = { "name": a, "count": 0 };
                            }
                            data["Payment"]["Payment Acceptance"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Payment"]["Payment Currency"] !== undefined) {
                        (jsonObj["Payment"]["Payment Currency"]).map(a => {
                            if (data["Payment"]["Payment Currency"][a] === undefined) {
                                data["Payment"]["Payment Currency"][a] = { "name": a, "count": 0 };
                            }
                            data["Payment"]["Payment Currency"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Payment"]["Checkout Buttons"] !== undefined) {
                        (jsonObj["Payment"]["Checkout Buttons"]).map(a => {
                            if (data["Payment"]["Checkout Buttons"][a] === undefined) {
                                data["Payment"]["Checkout Buttons"][a] = { "name": a, "count": 0 };
                            }
                            data["Payment"]["Checkout Buttons"][a]["count"] += 1;
                        });
                    }
                }

                if (jsonObj["Widgets"] !== undefined) {
                    if (total["Widgets"][datasets[i]] === undefined) {
                        total["Widgets"][datasets[i]] = { count: 1 };
                    } else {
                        total["Widgets"][datasets[i]]["count"] += 1;
                    }
                    if (jsonObj["Widgets"]["Live Chat"] !== undefined) {
                        (jsonObj["Widgets"]["Live Chat"]).map(a => {
                            if (data["Widgets"]["Live Chat"][a] === undefined) {
                                data["Widgets"]["Live Chat"][a] = { "name": a, "count": 0 };
                            }
                            data["Widgets"]["Live Chat"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Widgets"]["Customer Login"] !== undefined) {
                        (jsonObj["Widgets"]["Customer Login"]).map(a => {
                            if (data["Widgets"]["Customer Login"][a] === undefined) {
                                data["Widgets"]["Customer Login"][a] = { "name": a, "count": 0 };
                            }
                            data["Widgets"]["Customer Login"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Widgets"]["Social Sharing"] !== undefined) {
                        (jsonObj["Widgets"]["Social Sharing"]).map(a => {
                            if (data["Widgets"]["Social Sharing"][a] === undefined) {
                                data["Widgets"]["Social Sharing"][a] = { "name": a, "count": 0 };
                            }
                            data["Widgets"]["Social Sharing"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Widgets"]["Schedule Management"] !== undefined) {
                        (jsonObj["Widgets"]["Schedule Management"]).map(a => {
                            if (data["Widgets"]["Schedule Management"][a] === undefined) {
                                data["Widgets"]["Schedule Management"][a] = { "name": a, "count": 0 };
                            }
                            data["Widgets"]["Schedule Management"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Widgets"]["Ticketing System"] !== undefined) {
                        (jsonObj["Widgets"]["Ticketing System"]).map(a => {
                            if (data["Widgets"]["Ticketing System"][a] === undefined) {
                                data["Widgets"]["Ticketing System"][a] = { "name": a, "count": 0 };
                            }
                            data["Widgets"]["Ticketing System"][a]["count"] += 1;
                        });
                    }
                    if (jsonObj["Widgets"]["Bookings"] !== undefined) {
                        (jsonObj["Widgets"]["Bookings"]).map(a => {
                            if (data["Widgets"]["Bookings"][a] === undefined) {
                                data["Widgets"]["Bookings"][a] = { "name": a, "count": 0 };
                            }
                            data["Widgets"]["Bookings"][a]["count"] += 1;
                        });
                    }
                }
            }
            results.push(data);
        }

        return res.status(200).json({
            message: "Successful",
            results: results,
            types: types,
            categoryTypes: categoryTypes,
            headers: headers,
            total: total
        });

    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.getTechnologyCountryView = async function (req, res) {

    const datasets = req.body.datasets;
    const industries = req.body.industries;
    const filename = req.body.fileName;

    let results = [];
    let jsonObj = {};
    let industryObj = {};
    let indObj = {};
    let data = {};

    try {

        for (let i = 0; i < datasets.length; i++) {

            let companies;
            if (filename !== "Master DB (Golden Source)") {
                companies = await CompanyItem.findAll({
                    attributes: ["industry", "asset"],
                    where: {
                        [Op.and]: [
                            { dataset: datasets[i] },
                            {
                                industry: {
                                    [Op.in]: industries
                                }
                            },
                            {
                                asset: {
                                    [Op.ne]: null
                                }
                            },
                            {
                                file_name: filename
                            }
                        ]
                    }
                });
            } else {
                companies = await CompanyItem.findAll({
                    attributes: ["industry", "asset"],
                    where: {
                        [Op.and]: [
                            { dataset: datasets[i] },
                            {
                                industry: {
                                    [Op.in]: industries
                                }
                            },
                            {
                                asset: {
                                    [Op.ne]: null
                                }
                            }
                        ]
                    }
                });
            }


            data[datasets[i]] = {
                "Advertising": {
                    "Ad Network": {},
                    "ads txt": {},
                    "Contextual Advertising": {},
                    "Ad Exchange": {},
                    "Facebook Exchange": {},
                    "Retargeting / Remarketing": {}
                },
                "Analytics": {
                    "Conversion Optimization": {},
                    "Tag Management": {},
                    "Advertiser Tracking": {},
                    "Audience Measurement": {},
                    "Lead Generation": {},
                    "Marketing Automation": {}
                },
                "Ecommerce": {
                    "Non Platform": {},
                    "Hosted Solution": {},
                    "Open Source": {},
                    "Multi-Channel": {},
                    "Enterprise": {},
                    "SMB Solution": {}
                },
                "Payment": {
                    "Payments Processor": {},
                    "Payment Acceptance": {},
                    "Payment Currency": {},
                    "Checkout Buttons": {}
                },
                "Widgets": {
                    "Live Chat": {},
                    "Customer Login": {},
                    "Social Sharing": {},
                    "Schedule Management": {},
                    "Ticketing System": {},
                    "Bookings": {}
                }
            }

            let adNetwork = 0;
            let adsTxt = 0;
            let contextualAds = 0;
            let adExchange = 0;
            let fbExchange = 0;
            let retargetingAds = 0;

            let conversionOpt = 0;
            let tagMng = 0;
            let adsTracking = 0;
            let audienceMeasurement = 0;
            let leadGeneration = 0;
            let marketAutomation = 0;

            let nonPlatform = 0;
            let hostedSolution = 0;
            let openSource = 0;
            let multiChannel = 0;
            let enterprise = 0;
            let smbSolution = 0;

            let payProcessor = 0;
            let payAcceptance = 0;
            let payCurrency = 0;
            let checkOurButton = 0;
            let PPPAPCCO = 0;
            let PAPCCO = 0;

            let liveChat = 0;
            let customerLogin = 0;
            let socialSharing = 0;
            let scheduleManagement = 0;
            let ticketingSystem = 0;
            let bookings = 0;

            let totalAdvertisingCount = 0;
            let totalSEOCount = 0;
            let totalAnalyticsCount = 0;
            let totalEcommerceCount = 0;
            let totalPaymentCount = 0;
            let totalWidgetsCount = 0;

            if (jsonObj[datasets[i]] === undefined) {
                jsonObj[datasets[i]] = {
                    "Advertising": {},
                    "Analytics": {},
                    "Ecommerce": {},
                    "Payment": {},
                    "Widgets": {}
                };
            }

            if (industryObj[datasets[i]] === undefined) industryObj[datasets[i]] = {};
            if (industryObj[datasets[i]]["Advertising"] === undefined) industryObj[datasets[i]]["Advertising"] = {};
            if (industryObj[datasets[i]]["Analytics"] === undefined) industryObj[datasets[i]]["Analytics"] = {};
            if (industryObj[datasets[i]]["Ecommerce"] === undefined) industryObj[datasets[i]]["Ecommerce"] = {};
            if (industryObj[datasets[i]]["Payment"] === undefined) industryObj[datasets[i]]["Payment"] = {};
            if (industryObj[datasets[i]]["Widgets"] === undefined) industryObj[datasets[i]]["Widgets"] = {};

            for (let j = 0; j < companies.length; j++) {

                industryObj[datasets[i]]["Advertising"][companies[j].industry] = [];
                industryObj[datasets[i]]["Analytics"][companies[j].industry] = [];
                industryObj[datasets[i]]["Ecommerce"][companies[j].industry] = [];
                industryObj[datasets[i]]["Payment"][companies[j].industry] = [];
                industryObj[datasets[i]]["Widgets"][companies[j].industry] = [];

                let assets = JSON.parse(companies[j]["asset"]);

                if (assets) {

                    indObj[companies[j].industry] === undefined ? indObj[companies[j].industry] = {} : null;

                    if (assets["Advertising"] !== undefined) {
                        if (assets["Advertising"]["Ad Network"] !== undefined) {
                            adNetwork += 1;
                            if (indObj[companies[j].industry]["Ad Network"] === undefined) indObj[companies[j].industry]["Ad Network"] = 1
                            else indObj[companies[j].industry]["Ad Network"] += 1;
                            (assets["Advertising"]["Ad Network"]).map(a => {
                                if (data[datasets[i]]["Advertising"]["Ad Network"][a] === undefined) {
                                    data[datasets[i]]["Advertising"]["Ad Network"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Advertising"]["Ad Network"][a]["count"] += 1;
                            });
                        }
                        if (assets["Advertising"]["ads txt"] !== undefined) {
                            adsTxt += 1;
                            if (indObj[companies[j].industry]["ads txt"] === undefined) indObj[companies[j].industry]["ads txt"] = 1
                            else indObj[companies[j].industry]["ads txt"] += 1;
                            (assets["Advertising"]["ads txt"]).map(a => {
                                if (data[datasets[i]]["Advertising"]["ads txt"][a] === undefined) {
                                    data[datasets[i]]["Advertising"]["ads txt"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Advertising"]["ads txt"][a]["count"] += 1;
                            });
                        }
                        if (assets["Advertising"]["Contextual Advertising"] !== undefined) {
                            contextualAds += 1;
                            if (indObj[companies[j].industry]["Contextual Advertising"] === undefined) indObj[companies[j].industry]["Contextual Advertising"] = 1
                            else indObj[companies[j].industry]["Contextual Advertising"] += 1;
                            (assets["Advertising"]["Contextual Advertising"]).map(a => {
                                if (data[datasets[i]]["Advertising"]["Contextual Advertising"][a] === undefined) {
                                    data[datasets[i]]["Advertising"]["Contextual Advertising"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Advertising"]["Contextual Advertising"][a]["count"] += 1;
                            });
                        }
                        if (assets["Advertising"]["Ad Exchange"] !== undefined) {
                            adExchange += 1;
                            if (indObj[companies[j].industry]["Ad Exchange"] === undefined) indObj[companies[j].industry]["Ad Exchange"] = 1
                            else indObj[companies[j].industry]["Ad Exchange"] += 1;
                            (assets["Advertising"]["Ad Exchange"]).map(a => {
                                if (data[datasets[i]]["Advertising"]["Ad Exchange"][a] === undefined) {
                                    data[datasets[i]]["Advertising"]["Ad Exchange"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Advertising"]["Ad Exchange"][a]["count"] += 1;
                            });
                        }
                        if (assets["Advertising"]["Facebook Exchange"] !== undefined) {
                            fbExchange += 1;
                            if (indObj[companies[j].industry]["Facebook Exchange"] === undefined) indObj[companies[j].industry]["Facebook Exchange"] = 1
                            else indObj[companies[j].industry]["Facebook Exchange"] += 1;
                            (assets["Advertising"]["Facebook Exchange"]).map(a => {
                                if (data[datasets[i]]["Advertising"]["Facebook Exchange"][a] === undefined) {
                                    data[datasets[i]]["Advertising"]["Facebook Exchange"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Advertising"]["Facebook Exchange"][a]["count"] += 1;
                            });
                        }
                        if (assets["Advertising"]["Retargeting / Remarketing"] !== undefined) {
                            retargetingAds += 1;
                            if (indObj[companies[j].industry]["Retargeting / Remarketing"] === undefined) indObj[companies[j].industry]["Retargeting / Remarketing"] = 1
                            else indObj[companies[j].industry]["Retargeting / Remarketing"] += 1;
                            (assets["Advertising"]["Retargeting / Remarketing"]).map(a => {
                                if (data[datasets[i]]["Advertising"]["Retargeting / Remarketing"][a] === undefined) {
                                    data[datasets[i]]["Advertising"]["Retargeting / Remarketing"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Advertising"]["Retargeting / Remarketing"][a]["count"] += 1;
                            });
                        }
                        totalAdvertisingCount += 1;
                    }

                    if (assets["Analytics and Tracking"] !== undefined) {
                        if (assets["Analytics and Tracking"]["Conversion Optimization"] !== undefined) {
                            conversionOpt += 1;
                            if (indObj[companies[j].industry]["Conversion Optimization"] === undefined) indObj[companies[j].industry]["Conversion Optimization"] = 1
                            else indObj[companies[j].industry]["Conversion Optimization"] += 1;
                            (assets["Analytics and Tracking"]["Conversion Optimization"]).map(a => {
                                if (data[datasets[i]]["Analytics"]["Conversion Optimization"][a] === undefined) {
                                    data[datasets[i]]["Analytics"]["Conversion Optimization"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Analytics"]["Conversion Optimization"][a]["count"] += 1;
                            });
                        }
                        if (assets["Analytics and Tracking"]["Tag Management"] !== undefined) {
                            tagMng += 1;
                            if (indObj[companies[j].industry]["Tag Management"] === undefined) indObj[companies[j].industry]["Tag Management"] = 1
                            else indObj[companies[j].industry]["Tag Management"] += 1;
                            let arr = assets["Analytics and Tracking"]["Tag Management"];

                            arr.map(a => {
                                if (data[datasets[i]]["Analytics"]["Tag Management"][a] === undefined) {
                                    data[datasets[i]]["Analytics"]["Tag Management"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Analytics"]["Tag Management"][a]["count"] += 1;
                            });
                        }
                        if (assets["Analytics and Tracking"]["Advertiser Tracking"] !== undefined) {
                            adsTracking += 1;
                            if (indObj[companies[j].industry]["Advertiser Tracking"] === undefined) indObj[companies[j].industry]["Advertiser Tracking"] = 1
                            else indObj[companies[j].industry]["Advertiser Tracking"] += 1;
                            (assets["Analytics and Tracking"]["Advertiser Tracking"]).map(a => {
                                if (data[datasets[i]]["Analytics"]["Advertiser Tracking"][a] === undefined) {
                                    data[datasets[i]]["Analytics"]["Advertiser Tracking"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Analytics"]["Advertiser Tracking"][a]["count"] += 1;
                            });
                        }
                        if (assets["Analytics and Tracking"]["Audience Measurement"] !== undefined) {
                            audienceMeasurement += 1;
                            if (indObj[companies[j].industry]["Audience Measurement"] === undefined) indObj[companies[j].industry]["Audience Measurement"] = 1
                            else indObj[companies[j].industry]["Audience Measurement"] += 1;
                            (assets["Analytics and Tracking"]["Audience Measurement"]).map(a => {
                                if (data[datasets[i]]["Analytics"]["Audience Measurement"][a] === undefined) {
                                    data[datasets[i]]["Analytics"]["Audience Measurement"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Analytics"]["Audience Measurement"][a]["count"] += 1;
                            });
                        }
                        if (assets["Analytics and Tracking"]["Lead Generation"] !== undefined) {
                            leadGeneration += 1;
                            if (indObj[companies[j].industry]["Lead Generation"] === undefined) indObj[companies[j].industry]["Lead Generation"] = 1
                            else indObj[companies[j].industry]["Lead Generation"] += 1;
                            (assets["Analytics and Tracking"]["Lead Generation"]).map(a => {
                                if (data[datasets[i]]["Analytics"]["Lead Generation"][a] === undefined) {
                                    data[datasets[i]]["Analytics"]["Lead Generation"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Analytics"]["Lead Generation"][a]["count"] += 1;
                            });
                        }
                        if (assets["Analytics and Tracking"]["Marketing Automation"] !== undefined) {
                            marketAutomation += 1;
                            if (indObj[companies[j].industry]["Marketing Automation"] === undefined) indObj[companies[j].industry]["Marketing Automation"] = 1
                            else indObj[companies[j].industry]["Marketing Automation"] += 1;
                            (assets["Analytics and Tracking"]["Marketing Automation"]).map(a => {
                                if (data[datasets[i]]["Analytics"]["Marketing Automation"][a] === undefined) {
                                    data[datasets[i]]["Analytics"]["Marketing Automation"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Analytics"]["Marketing Automation"][a]["count"] += 1;
                            });
                        }
                        totalAnalyticsCount += 1;
                    }

                    if (assets["Ecommerce"] !== undefined) {
                        if (assets["Ecommerce"]["Non Platform"] !== undefined) {
                            nonPlatform += 1;
                            if (indObj[companies[j].industry]["Non Platform"] === undefined) indObj[companies[j].industry]["Non Platform"] = 1
                            else indObj[companies[j].industry]["Non Platform"] += 1;
                            (assets["Ecommerce"]["Non Platform"]).map(a => {
                                if (data[datasets[i]]["Ecommerce"]["Non Platform"][a] === undefined) {
                                    data[datasets[i]]["Ecommerce"]["Non Platform"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Ecommerce"]["Non Platform"][a]["count"] += 1;
                            });
                        }
                        if (assets["Ecommerce"]["Hosted Solution"] !== undefined) {
                            hostedSolution += 1;
                            if (indObj[companies[j].industry]["Hosted Solution"] === undefined) indObj[companies[j].industry]["Hosted Solution"] = 1
                            else indObj[companies[j].industry]["Hosted Solution"] += 1;
                            (assets["Ecommerce"]["Hosted Solution"]).map(a => {
                                if (data[datasets[i]]["Ecommerce"]["Hosted Solution"][a] === undefined) {
                                    data[datasets[i]]["Ecommerce"]["Hosted Solution"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Ecommerce"]["Hosted Solution"][a]["count"] += 1;
                            });
                        }
                        if (assets["Ecommerce"]["Open Source"] !== undefined) {
                            openSource += 1;
                            if (indObj[companies[j].industry]["Open Source"] === undefined) indObj[companies[j].industry]["Open Source"] = 1
                            else indObj[companies[j].industry]["Open Source"] += 1;
                            (assets["Ecommerce"]["Open Source"]).map(a => {
                                if (data[datasets[i]]["Ecommerce"]["Open Source"][a] === undefined) {
                                    data[datasets[i]]["Ecommerce"]["Open Source"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Ecommerce"]["Open Source"][a]["count"] += 1;
                            });
                        }
                        if (assets["Ecommerce"]["Multi-Channel"] !== undefined) {
                            multiChannel += 1;
                            if (indObj[companies[j].industry]["Multi-Channel"] === undefined) indObj[companies[j].industry]["Multi-Channel"] = 1
                            else indObj[companies[j].industry]["Multi-Channel"] += 1;
                            (assets["Ecommerce"]["Multi-Channel"]).map(a => {
                                if (data[datasets[i]]["Ecommerce"]["Multi-Channel"][a] === undefined) {
                                    data[datasets[i]]["Ecommerce"]["Multi-Channel"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Ecommerce"]["Multi-Channel"][a]["count"] += 1;
                            });
                        }
                        if (assets["Ecommerce"]["Enterprise"] !== undefined) {
                            enterprise += 1;
                            if (indObj[companies[j].industry]["Enterprise"] === undefined) indObj[companies[j].industry]["Enterprise"] = 1
                            else indObj[companies[j].industry]["Enterprise"] += 1;
                            (assets["Ecommerce"]["Enterprise"]).map(a => {
                                if (data[datasets[i]]["Ecommerce"]["Enterprise"][a] === undefined) {
                                    data[datasets[i]]["Ecommerce"]["Enterprise"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Ecommerce"]["Enterprise"][a]["count"] += 1;
                            });
                        }
                        if (assets["Ecommerce"]["SMB Solution"] !== undefined) {
                            smbSolution += 1;
                            if (indObj[companies[j].industry]["SMB Solution"] === undefined) indObj[companies[j].industry]["SMB Solution"] = 1
                            else indObj[companies[j].industry]["SMB Solution"] += 1;
                            (assets["Ecommerce"]["SMB Solution"]).map(a => {
                                if (data[datasets[i]]["Ecommerce"]["SMB Solution"][a] === undefined) {
                                    data[datasets[i]]["Ecommerce"]["SMB Solution"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Ecommerce"]["SMB Solution"][a]["count"] += 1;
                            });
                        }
                        totalEcommerceCount += 1;
                    }

                    if (assets["Payment"] !== undefined) {
                        if (assets["Payment"]["Payments Processor"] !== undefined) {
                            payProcessor += 1;
                            if (indObj[companies[j].industry]["Payments Processor"] === undefined) indObj[companies[j].industry]["Payments Processor"] = 1
                            else indObj[companies[j].industry]["Payments Processor"] += 1;
                            (assets["Payment"]["Payments Processor"]).map(a => {
                                if (data[datasets[i]]["Payment"]["Payments Processor"][a] === undefined) {
                                    data[datasets[i]]["Payment"]["Payments Processor"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Payment"]["Payments Processor"][a]["count"] += 1;
                            });
                        }
                        if (assets["Payment"]["Payment Acceptance"] !== undefined) {
                            payAcceptance += 1;
                            if (indObj[companies[j].industry]["Payment Acceptance"] === undefined) indObj[companies[j].industry]["Payment Acceptance"] = 1
                            else indObj[companies[j].industry]["Payment Acceptance"] += 1;
                            (assets["Payment"]["Payment Acceptance"]).map(a => {
                                if (data[datasets[i]]["Payment"]["Payment Acceptance"][a] === undefined) {
                                    data[datasets[i]]["Payment"]["Payment Acceptance"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Payment"]["Payment Acceptance"][a]["count"] += 1;
                            });
                        }
                        if (assets["Payment"]["Payment Currency"] !== undefined) {
                            payCurrency += 1;
                            if (indObj[companies[j].industry]["Payment Currency"] === undefined) indObj[companies[j].industry]["Payment Currency"] = 1
                            else indObj[companies[j].industry]["Payment Currency"] += 1;
                            (assets["Payment"]["Payment Currency"]).map(a => {
                                if (data[datasets[i]]["Payment"]["Payment Currency"][a] === undefined) {
                                    data[datasets[i]]["Payment"]["Payment Currency"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Payment"]["Payment Currency"][a]["count"] += 1;
                            });
                        }
                        if (assets["Payment"]["Checkout Buttons"] !== undefined) {
                            checkOurButton += 1;
                            if (indObj[companies[j].industry]["Checkout Buttons"] === undefined) indObj[companies[j].industry]["Checkout Buttons"] = 1
                            else indObj[companies[j].industry]["Checkout Buttons"] += 1;
                            (assets["Payment"]["Checkout Buttons"]).map(a => {
                                if (data[datasets[i]]["Payment"]["Checkout Buttons"][a] === undefined) {
                                    data[datasets[i]]["Payment"]["Checkout Buttons"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Payment"]["Checkout Buttons"][a]["count"] += 1;
                            });
                        }
                        if (assets["Payment"]["Payment Acceptance"] !== undefined &&
                            assets["Payment"]["Payment Currency"] !== undefined &&
                            assets["Payment"]["Checkout Buttons"] !== undefined
                        ) {
                            PAPCCO += 1;
                            if (indObj[companies[j].industry]["PAPCCO"] === undefined) indObj[companies[j].industry]["PAPCCO"] = 1
                            else indObj[companies[j].industry]["PAPCCO"] += 1;
                            // (assets["Payment"]["Payments Acceptance"]).map(a => {
                            //     if (data[datasets[i]]["Payment"]["PAPCCO"][a] === undefined) {
                            //         data[datasets[i]]["Payment"]["PAPCCO"][a] = { "name": a, "count": 0 };
                            //     }
                            //     data[datasets[i]]["Payment"]["PAPCCO"][a]["count"] += 1;
                            // });
                        }

                        if (assets["Payment"]["Payments Processor"] !== undefined &&
                            assets["Payment"]["Payment Acceptance"] !== undefined &&
                            assets["Payment"]["Payment Currency"] !== undefined &&
                            assets["Payment"]["Checkout Buttons"] !== undefined
                        ) {
                            PPPAPCCO += 1;
                            if (indObj[companies[j].industry]["PPPAPCCO"] === undefined) indObj[companies[j].industry]["PPPAPCCO"] = 1
                            else indObj[companies[j].industry]["PPPAPCCO"] += 1;
                            // (assets["Payment"]["Payments Currency"]).map(a => {
                            //     if (data[datasets[i]]["Payment"]["PPPAPCCO"][a] === undefined) {
                            //         data[datasets[i]]["Payment"]["PPPAPCCO"][a] = { "name": a, "count": 0 };
                            //     }
                            //     data[datasets[i]]["Payment"]["PPPAPCCO"][a]["count"] += 1;
                            // });
                        }
                        totalPaymentCount += 1;
                    }

                    if (assets["Widgets"] !== undefined) {
                        if (assets["Widgets"]["Live Chat"] !== undefined) {
                            liveChat += 1;
                            if (indObj[companies[j].industry]["Live Chat"] === undefined) indObj[companies[j].industry]["Live Chat"] = 1
                            else indObj[companies[j].industry]["Live Chat"] += 1;
                            (assets["Widgets"]["Live Chat"]).map(a => {
                                if (data[datasets[i]]["Widgets"]["Live Chat"][a] === undefined) {
                                    data[datasets[i]]["Widgets"]["Live Chat"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Widgets"]["Live Chat"][a]["count"] += 1;
                            });
                        }
                        if (assets["Widgets"]["Login"] !== undefined) {
                            customerLogin += 1;
                            if (indObj[companies[j].industry]["Login"] === undefined) indObj[companies[j].industry]["Login"] = 1
                            else indObj[companies[j].industry]["Login"] += 1;
                            // (assets["Widgets"]["Login"]).map(a => {
                            //     if (data[datasets[i]]["Widgets"]["Login"][a] === undefined) {
                            //         data[datasets[i]]["Widgets"]["Login"][a] = { "name": a, "count": 0 };
                            //     }
                            //     data[datasets[i]]["Widgets"]["Login"][a]["count"] += 1;
                            // });
                        }
                        if (assets["Widgets"]["Social Sharing"] !== undefined) {
                            socialSharing += 1;
                            if (indObj[companies[j].industry]["Social Sharing"] === undefined) indObj[companies[j].industry]["Social Sharing"] = 1
                            else indObj[companies[j].industry]["Social Sharing"] += 1;
                            (assets["Widgets"]["Social Sharing"]).map(a => {
                                if (data[datasets[i]]["Widgets"]["Social Sharing"][a] === undefined) {
                                    data[datasets[i]]["Widgets"]["Social Sharing"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Widgets"]["Social Sharing"][a]["count"] += 1;
                            });
                        }
                        if (assets["Widgets"]["Schedule Management"] !== undefined) {
                            scheduleManagement += 1;
                            if (indObj[companies[j].industry]["Schedule Management"] === undefined) indObj[companies[j].industry]["Schedule Management"] = 1
                            else indObj[companies[j].industry]["Schedule Management"] += 1;
                            (assets["Widgets"]["Schedule Management"]).map(a => {
                                if (data[datasets[i]]["Widgets"]["Schedule Management"][a] === undefined) {
                                    data[datasets[i]]["Widgets"]["Schedule Management"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Widgets"]["Schedule Management"][a]["count"] += 1;
                            });
                        }
                        if (assets["Widgets"]["Ticketing System"] !== undefined) {
                            ticketingSystem += 1;
                            if (indObj[companies[j].industry]["Ticketing System"] === undefined) indObj[companies[j].industry]["Ticketing System"] = 1
                            else indObj[companies[j].industry]["Ticketing System"] += 1;
                            (assets["Widgets"]["Ticketing System"]).map(a => {
                                if (data[datasets[i]]["Widgets"]["Ticketing System"][a] === undefined) {
                                    data[datasets[i]]["Widgets"]["Ticketing System"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Widgets"]["Ticketing System"][a]["count"] += 1;
                            });
                        }
                        if (assets["Widgets"]["Bookings"] !== undefined) {
                            bookings += 1;
                            if (indObj[companies[j].industry]["Bookings"] === undefined) indObj[companies[j].industry]["Bookings"] = 1
                            else indObj[companies[j].industry]["Bookings"] += 1;
                            (assets["Widgets"]["Bookings"]).map(a => {
                                if (data[datasets[i]]["Widgets"]["Bookings"][a] === undefined) {
                                    data[datasets[i]]["Widgets"]["Bookings"][a] = { "name": a, "count": 0 };
                                }
                                data[datasets[i]]["Widgets"]["Bookings"][a]["count"] += 1;
                            });
                        }
                        totalWidgetsCount += 1;
                    }

                    if (indObj[companies[j].industry]) {
                        industryObj[datasets[i]]["Advertising"][companies[j].industry] = [
                            companies[j].industry,
                            indObj[companies[j].industry]["Ad Network"] ? (indObj[companies[j].industry]["Ad Network"] / adNetwork) * 100 : 0,
                            indObj[companies[j].industry]["ads txt"] ? (indObj[companies[j].industry]["ads txt"] / adsTxt) * 100 : 0,
                            indObj[companies[j].industry]["Contextual Advertising"] ? (indObj[companies[j].industry]["Contextual Advertising"] / contextualAds) * 100 : 0,
                            indObj[companies[j].industry]["Ad Exchange"] ? (indObj[companies[j].industry]["Ad Exchange"] / adExchange) * 100 : 0,
                            indObj[companies[j].industry]["Facebook Exchange"] ? (indObj[companies[j].industry]["Facebook Exchange"] / fbExchange) * 100 : 0,
                            indObj[companies[j].industry]["Retargeting / Remarketing"] ? (indObj[companies[j].industry]["Retargeting / Remarketing"] / retargetingAds) * 100 : 0
                        ];
                        industryObj[datasets[i]]["Analytics"][companies[j].industry] = [
                            companies[j].industry,
                            indObj[companies[j].industry]["Conversion Optimization"] ? (indObj[companies[j].industry]["Conversion Optimization"] / conversionOpt) * 100 : 0,
                            indObj[companies[j].industry]["Tag Management"] ? (indObj[companies[j].industry]["Tag Management"] / tagMng) * 100 : 0,
                            indObj[companies[j].industry]["Advertiser Tracking"] ? (indObj[companies[j].industry]["Advertiser Tracking"] / adsTracking) * 100 : 0,
                            indObj[companies[j].industry]["Audience Measurement"] ? (indObj[companies[j].industry]["Audience Measurement"] / audienceMeasurement) * 100 : 0,
                            indObj[companies[j].industry]["Lead Generation"] ? (indObj[companies[j].industry]["Lead Generation"] / leadGeneration) * 100 : 0,
                            indObj[companies[j].industry]["Marketing Automation"] ? (indObj[companies[j].industry]["Marketing Automation"] / marketAutomation) * 100 : 0
                        ];
                        industryObj[datasets[i]]["Ecommerce"][companies[j].industry] = [
                            companies[j].industry,
                            indObj[companies[j].industry]["Non Platform"] ? (indObj[companies[j].industry]["Non Platform"] / nonPlatform) * 100 : 0,
                            indObj[companies[j].industry]["Hosted Solution"] ? (indObj[companies[j].industry]["Hosted Solution"] / hostedSolution) * 100 : 0,
                            indObj[companies[j].industry]["Open Source"] ? (indObj[companies[j].industry]["Open Source"] / openSource) * 100 : 0,
                            indObj[companies[j].industry]["Multi-Channel"] ? (indObj[companies[j].industry]["Multi-Channel"] / multiChannel) * 100 : 0,
                            indObj[companies[j].industry]["Enterprise"] ? (indObj[companies[j].industry]["Enterprise"] / enterprise) * 100 : 0,
                            indObj[companies[j].industry]["SMB Solution"] ? (indObj[companies[j].industry]["SMB Solution"] / smbSolution) * 100 : 0
                        ];
                        industryObj[datasets[i]]["Payment"][companies[j].industry] = [
                            companies[j].industry,
                            indObj[companies[j].industry]["Payments Processor"] ? (indObj[companies[j].industry]["Payments Processor"] / payProcessor) * 100 : 0,
                            indObj[companies[j].industry]["Payment Acceptance"] ? (indObj[companies[j].industry]["Payment Acceptance"] / payAcceptance) * 100 : 0,
                            indObj[companies[j].industry]["Payment Currency"] ? (indObj[companies[j].industry]["Payment Currency"] / payCurrency) * 100 : 0,
                            indObj[companies[j].industry]["Checkout Buttons"] ? (indObj[companies[j].industry]["Checkout Buttons"] / checkOurButton) * 100 : 0,
                            indObj[companies[j].industry]["PAPCCO"] ? (indObj[companies[j].industry]["PAPCCO"] / PAPCCO) * 100 : 0,
                            indObj[companies[j].industry]["PPPAPCCO"] ? (indObj[companies[j].industry]["PPPAPCCO"] / PPPAPCCO) * 100 : 0
                        ];
                        industryObj[datasets[i]]["Widgets"][companies[j].industry] = [
                            companies[j].industry,
                            indObj[companies[j].industry]["Live Chat"] ? (indObj[companies[j].industry]["Live Chat"] / liveChat) * 100 : 0,
                            indObj[companies[j].industry]["Login"] ? (indObj[companies[j].industry]["Login"] / customerLogin) * 100 : 0,
                            indObj[companies[j].industry]["Social Sharing"] ? (indObj[companies[j].industry]["Social Sharing"] / socialSharing) * 100 : 0,
                            indObj[companies[j].industry]["Schedule Management"] ? (indObj[companies[j].industry]["Schedule Management"] / scheduleManagement) * 100 : 0,
                            indObj[companies[j].industry]["Ticketing System"] ? (indObj[companies[j].industry]["Ticketing System"] / ticketingSystem) * 100 : 0,
                            indObj[companies[j].industry]["Bookings"] ? (indObj[companies[j].industry]["Bookings"] / bookings) * 100 : 0
                        ];
                    }
                }
            }

            jsonObj[datasets[i]]["Advertising"] = {
                "Type": "Advertising",
                "Count": totalAdvertisingCount,
                "Ad Network": {
                    percent: isNaN(Math.round((adNetwork / totalAdvertisingCount) * 100)) ? 0 : Math.round((adNetwork / totalAdvertisingCount) * 100),
                    count: adNetwork
                },
                "Ads Txt": {
                    percent: isNaN(Math.round((adsTxt / totalAdvertisingCount) * 100)) ? 0 : Math.round((adsTxt / totalAdvertisingCount) * 100),
                    count: adsTxt
                },
                "Contextual Ad": {
                    percent: isNaN(Math.round((contextualAds / totalAdvertisingCount) * 100)) ? 0 : Math.round((contextualAds / totalAdvertisingCount) * 100),
                    count: contextualAds
                },
                "Ad Exchange": {
                    percent: isNaN(Math.round((adExchange / totalAdvertisingCount) * 100)) ? 0 : Math.round((adExchange / totalAdvertisingCount) * 100),
                    count: adExchange
                },
                "Facebook Exchange": {
                    percent: isNaN(Math.round((fbExchange / totalAdvertisingCount) * 100)) ? 0 : Math.round((fbExchange / totalAdvertisingCount) * 100),
                    count: fbExchange
                },
                "Retargeting": {
                    percent: isNaN(Math.round((retargetingAds / totalAdvertisingCount) * 100)) ? 0 : Math.round((retargetingAds / totalAdvertisingCount) * 100),
                    count: retargetingAds
                }
            }

            jsonObj[datasets[i]]["Analytics"] = {
                "Type": "Analytics",
                "Count": totalAnalyticsCount,
                "Conversion Optimization": {
                    percent: isNaN(Math.round((conversionOpt / totalAnalyticsCount) * 100)) ? 0 : Math.round((conversionOpt / totalAnalyticsCount) * 100),
                    count: conversionOpt
                },
                "Tag Management": {
                    percent: isNaN(Math.round((tagMng / totalAnalyticsCount) * 100)) ? 0 : Math.round((tagMng / totalAnalyticsCount) * 100),
                    count: tagMng
                },
                "Advertising Tracking": {
                    percent: isNaN(Math.round((adsTracking / totalAnalyticsCount) * 100)) ? 0 : Math.round((adsTracking / totalAnalyticsCount) * 100),
                    count: adsTracking
                },
                "Audience Measurement": {
                    percent: isNaN(Math.round((audienceMeasurement / totalAnalyticsCount) * 100)) ? 0 : Math.round((audienceMeasurement / totalAnalyticsCount) * 100),
                    count: audienceMeasurement
                },
                "Lead Generation": {
                    percent: isNaN(Math.round((leadGeneration / totalAnalyticsCount) * 100)) ? 0 : Math.round((leadGeneration / totalAnalyticsCount) * 100),
                    count: leadGeneration
                },
                "Marketing Automation": {
                    percent: isNaN(Math.round((marketAutomation / totalAnalyticsCount) * 100)) ? 0 : Math.round((marketAutomation / totalAnalyticsCount) * 100),
                    count: marketAutomation
                }
            }

            jsonObj[datasets[i]]["Ecommerce"] = {
                "Type": "Ecommerce",
                "Count": totalEcommerceCount,
                "Non Platform": {
                    percent: isNaN(Math.round((nonPlatform / totalEcommerceCount) * 100)) ? 0 : Math.round((nonPlatform / totalEcommerceCount) * 100),
                    count: nonPlatform
                },
                "Hosted Solution": {
                    percent: isNaN(Math.round((hostedSolution / totalEcommerceCount) * 100)) ? 0 : Math.round((hostedSolution / totalEcommerceCount) * 100),
                    count: hostedSolution
                },
                "Open Source": {
                    percent: isNaN(Math.round((openSource / totalEcommerceCount) * 100)) ? 0 : Math.round((openSource / totalEcommerceCount) * 100),
                    count: openSource
                },
                "Multi-Channel": {
                    percent: isNaN(Math.round((multiChannel / totalEcommerceCount) * 100)) ? 0 : Math.round((multiChannel / totalEcommerceCount) * 100),
                    count: multiChannel
                },
                "Enterprise": {
                    percent: isNaN(Math.round((enterprise / totalEcommerceCount) * 100)) ? 0 : Math.round((enterprise / totalEcommerceCount) * 100),
                    count: enterprise
                },
                "SMB Solution": {
                    percent: isNaN(Math.round((smbSolution / totalEcommerceCount) * 100)) ? 0 : Math.round((smbSolution / totalEcommerceCount) * 100),
                    count: smbSolution
                }
            }

            jsonObj[datasets[i]]["Payment"] = {
                "Type": "Payment",
                "Count": totalPaymentCount,
                "Payments Processor": {
                    percent: isNaN(Math.round((payProcessor / totalPaymentCount) * 100)) ? 0 : Math.round((payProcessor / totalPaymentCount) * 100),
                    count: payProcessor
                },
                "Payment Acceptance": {
                    percent: isNaN(Math.round((payAcceptance / totalPaymentCount) * 100)) ? 0 : Math.round((payAcceptance / totalPaymentCount) * 100),
                    count: payAcceptance
                },
                "Payment Currency": {
                    percent: isNaN(Math.round((payCurrency / totalPaymentCount) * 100)) ? 0 : Math.round((payCurrency / totalPaymentCount) * 100),
                    count: payCurrency
                },
                "Checkout Buttons": {
                    percent: isNaN(Math.round((checkOurButton / totalPaymentCount) * 100)) ? 0 : Math.round((checkOurButton / totalPaymentCount) * 100),
                    count: checkOurButton
                },
                "PP, PA, PC, CO": {
                    percent: isNaN(Math.round((PPPAPCCO / totalPaymentCount) * 100)) ? 0 : Math.round((PPPAPCCO / totalPaymentCount) * 100),
                    count: PPPAPCCO
                },
                "PA & PC CO": {
                    percent: isNaN(Math.round((PAPCCO / totalPaymentCount) * 100)) ? 0 : Math.round((PAPCCO / totalPaymentCount) * 100),
                    count: PAPCCO
                }
            }

            jsonObj[datasets[i]]["Widgets"] = {
                "Type": "Widgets",
                "Count": totalWidgetsCount,
                "Live Chat": {
                    percent: isNaN(Math.round((liveChat / totalWidgetsCount) * 100)) ? 0 : Math.round((liveChat / totalWidgetsCount) * 100),
                    count: liveChat
                },
                "Customer Login": {
                    percent: isNaN(Math.round((customerLogin / totalWidgetsCount) * 100)) ? 0 : Math.round((customerLogin / totalWidgetsCount) * 100),
                    count: customerLogin
                },
                "Social Sharing": {
                    percent: isNaN(Math.round((socialSharing / totalWidgetsCount) * 100)) ? 0 : Math.round((socialSharing / totalWidgetsCount) * 100),
                    count: socialSharing
                },
                "Schedule Management": {
                    percent: isNaN(Math.round((scheduleManagement / totalWidgetsCount) * 100)) ? 0 : Math.round((scheduleManagement / totalWidgetsCount) * 100),
                    count: scheduleManagement
                },
                "Ticketing System": {
                    percent: isNaN(Math.round((ticketingSystem / totalWidgetsCount) * 100)) ? 0 : Math.round((ticketingSystem / totalWidgetsCount) * 100),
                    count: ticketingSystem
                },
                "Bookings": {
                    percent: isNaN(Math.round((bookings / totalWidgetsCount) * 100)) ? 0 : Math.round((bookings / totalWidgetsCount) * 100),
                    count: bookings
                }
            }

        }

        return res.status(200).json({
            message: "Successful",
            results: jsonObj,
            industry: industryObj,
            ind: indObj,
            industryProvider: data
        });

    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.uploadPersonnels = async function (req, res) {
    let form = new formidable.IncomingForm();
    form.parse(req, (err, fields, files) => {

        const wb = XLSX.readFile(files.file.path, { raw: true });

        const wsname = wb.SheetNames[0];

        const ws = wb.Sheets[wsname];

        const data = XLSX.utils.sheet_to_json(ws, { header: 1 });

        var values = {};

        data.forEach(function (row) {
            if (row.length >= 4) {
                var co_name = row[0];
                var p_name = row[1];
                var attr = row[2];
                var val = row[3];
                if (values[co_name] === undefined) {
                    values[co_name] = {
                        name: co_name,
                        personnels: {}
                    };
                }
                if (values[co_name].personnels[p_name] === undefined) {
                    values[co_name].personnels[p_name] = {
                        co_name: co_name,
                        p_name: p_name,
                        attr: {
                            industry: [],
                            industry_second_level: [],
                            industry_third_level: [],
                        },
                    }
                }
                if (attr === 'industry') {
                    var industry = row[3] !== undefined ? row[3] : null;
                    var industry_second_level = row[4] !== undefined ? row[4] : null;
                    var industry_third_level = row[5] !== undefined ? row[5] : null;
                    if (industry) {
                        values[co_name].personnels[p_name].attr.industry.push(industry);
                    }
                    if (industry_second_level) {
                        values[co_name].personnels[p_name].attr.industry_second_level.push(industry_second_level);
                    }
                    if (industry_third_level) {
                        values[co_name].personnels[p_name].attr.industry_third_level.push(industry_third_level);
                    }
                } else {
                    if (values[co_name].personnels[p_name].attr[attr] === undefined) {
                        values[co_name].personnels[p_name].attr[attr] = [];
                    }
                    if (val) {
                        values[co_name].personnels[p_name].attr[attr].push(val);
                    }
                }
            }
        });
        var companies = Object.values(values);
        var items = [];
        companies.forEach(function (company) {
            var personnels = Object.values(company.personnels).map(function (person) {
                var p_name = person.p_name;
                var co_name = person.co_name;
                var attr = person.attr;
                var p = {};
                p.personnel_name = p_name;
                p.title = 'cannot verify';
                if (attr.title && attr.title.length > 0) {
                    p.title = attr.title.join(',');
                }
                p.phone = null;
                if (attr.phone && attr.phone.length > 0) {
                    p.phone = attr.phone.join(',');
                }
                p.email = null;
                if (attr.email && attr.email.length > 0) {
                    p.email = attr.email.join(',');
                }
                p.status = null;
                if (attr.status && attr.status.length > 0) {
                    p.status = attr.status.join(',');
                }
                p.role = 'cannot verify';
                if (attr.role && attr.role.length > 0) {
                    p.role = attr.role.join(',');
                }
                p.seniority = 'cannot verify';
                if (attr.seniority && attr.seniority.length > 0) {
                    p.seniority = attr.seniority.join(',');
                }
                p.company_name = co_name;
                p.overall_knapshot_score = -1;
                if (attr.overallKnapshotScore && attr.overallKnapshotScore.length > 0) {
                    p.overall_knapshot_score = parseFloat(attr.overallKnapshotScore.join('-'));
                }
                p.organization_type = 'cannot verify';
                if (attr.organizationType && attr.organizationType.length > 0) {
                    p.organization_type = attr.organizationType.join(',');
                }
                p.year_in_operation = 'cannot verify';
                if (attr.yearOfOperation && attr.yearOfOperation.length > 0) {
                    p.year_in_operation = attr.yearOfOperation.join(',');
                }
                p.total_offices_region = -1;
                if (attr.totalOfficesByCountryOfPresence && attr.totalOfficesByCountryOfPresence.length > 0) {
                    p.total_offices_region = parseInt(attr.totalOfficesByCountryOfPresence.join(','), 10);
                }
                p.main_hq_location_region = 'cannot verify';
                if (attr.mainHqLocation && attr.mainHqLocation.length > 0) {
                    p.main_hq_location_region = attr.mainHqLocation.join(',');
                }
                return p;
            });
            items.push(...personnels);
        });

        Personnel
            .truncate()
            .then(function () {
                Personnel.bulkCreate(items).then(function () {
                    res.json({
                        meta: {
                            code: 200,
                            success: true,
                            message: 'Uploaded successfully',
                        },
                        personnels: items,
                        values: values,
                    })
                }).catch(function (e) {
                    throw e;
                });
            }).catch(function (e) {
                throw e;
            });

    });
};

exports.digitalPresenceFilter = async function (req, res) {

    let dataset = req.body.dataset;
    let file_name = req.body.file_name;
    let frimographicFilter = req.body.frimographicFilter;

    let twitterData = [{ label: "Has", count: 0 }, { label: "Doesn't", count: 0 }],
        facebookData = [{ label: "Has", count: 0 }, { label: "Doesn't", count: 0 }],
        linkedInData = [{ label: "Has", count: 0 }, { label: "Doesn't", count: 0 }],
        instagramData = [{ label: "Has", count: 0 }, { label: "Doesn't", count: 0 }],
        emailData = [{ label: "Has", count: 0 }, { label: "Doesn't", count: 0 }],
        addressData = [{ label: "Has", count: 0 }, { label: "Doesn't", count: 0 }],
        phoneData = [{ label: "Has", count: 0 }, { label: "Doesn't", count: 0 }],
        websiteData = [{ label: "Has", count: 0 }, { label: "Doesn't", count: 0 }];

    let basic = 0, intermediate = 0, high = 0, advance = 0
    let zero = 0, _1to2 = 0, _3to5 = 0, _gt6 = 0
    let digitalEngagement = [], totalDirectoryPresence = []
    let review = []
    let whereFilter = [{ dataset }];

    if (file_name !== "Master DB (Golden Source)") whereFilter.push({ file_name });

    frimographicFilter && frimographicFilter.industry && whereFilter.push({ industry: { [Op.or]: frimographicFilter.industry } })
    frimographicFilter && frimographicFilter.main_hq_location && whereFilter.push({ main_hq_location: { [Op.or]: frimographicFilter.main_hq_location } })
    frimographicFilter && frimographicFilter.emp_size && whereFilter.push({ total_personnel: { [Op.or]: frimographicFilter.emp_size } })
    frimographicFilter && frimographicFilter.total_personnel && whereFilter.push({ company_name: { [Op.or]: frimographicFilter.total_personnel } })

    try {
        await Company.findAll({
            where: {
                [Op.and]: whereFilter
            },
            attributes: ["company_name", "twitter", "facebook", "linkedIn", "instagram", "company_email_address", "address", "main_line_number", "website", "no_of_directory_presence", "overall_knapshot_score"],
            include: [
                { model: Directory }
            ]
        }).then(COMP => {
            COMP.map(x => {
                const { twitter, facebook, linkedIn, instagram, company_email_address, address, main_line_number, website, no_of_directory_presence, overall_knapshot_score, directories } = x.dataValues

                let filter = directories.filter(d => ["marketplace", "infoDirectory", "locationDirectory", "jobDirectory", "forum", "bloggers"].includes(d.directory))

                if (twitter) twitterData[0].count += 1
                else twitterData[1].count += 1
                if (facebook) facebookData[0].count += 1
                else facebookData[1].count += 1
                if (linkedIn) linkedInData[0].count += 1
                else linkedInData[1].count += 1
                if (instagram) instagramData[0].count += 1
                else instagramData[1].count += 1
                if (company_email_address) emailData[0].count += 1
                else emailData[1].count += 1
                if (address) addressData[0].count += 1
                else addressData[1].count += 1
                if (main_line_number) phoneData[0].count += 1
                else phoneData[1].count += 1
                if (website) websiteData[0].count += 1
                else websiteData[1].count += 1

                if (overall_knapshot_score < 2) basic += 1;
                if (overall_knapshot_score >= 2 && overall_knapshot_score < 5) intermediate += 1;
                if (overall_knapshot_score >= 5 && overall_knapshot_score < 8) high += 1;
                if (overall_knapshot_score >= 8) advance += 1;

                let dirObj = { default: 0 }
                for (let directory in filter) {
                    if (!filter.hasOwnProperty(directory)) continue;
                    let dirName = filter[directory].directory
                    dirObj[dirName] = dirObj[dirName] ? dirObj[dirName] + 1 : 1
                }
                let totalMaxDir = Math.max(...Object.values(dirObj))

                if (totalMaxDir === 0) zero += 1;
                if (totalMaxDir >= 1 && totalMaxDir <= 2) _1to2 += 1;
                if (totalMaxDir >= 3 && totalMaxDir <= 5) _3to5 += 1;
                if (totalMaxDir >= 6) _gt6 += 1;

            })
        })

        digitalEngagement.push({
            "KS Score 1-3": basic,
            "KS Score 3-5": intermediate,
            "KS Score 5-7": high,
            "KS Score > 7": advance
        })

        totalDirectoryPresence.push({
            "0 Presence": zero,
            "1 - 2": _1to2,
            "3 - 5": _3to5,
            ">6": _gt6
        })

        return res.status(200).json({
            message: "Successful",
            results: {
                websites: websiteData,
                email: emailData,
                phone: phoneData,
                address: addressData,
                twitter: twitterData,
                facebook: facebookData,
                linkedIn: linkedInData,
                instagram: instagramData,
                directoryPresence: totalDirectoryPresence,
                digitalEngagement: digitalEngagement,
                review: review
            }
        });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }

    // try{
    //     await Directory.findAll({
    //         where : {
    //             [Op.and]: whereFilter
    //         },
    //         attributes: ["company_name", "link"]
    //     }).then(DIRECT =>{
    //         DIRECT.map(x =>{
    //         })
    //     })
    // }catch(error){
    //     return res.status(500).json({message: error.message})
    // }
}

exports.digitalEngagementSelect = async function (req, res) {

    let file_name = req.body.file_name;
    let dataset = req.body.dataset;
    let frimographicFilter = req.body.frimographicFilter;
    let digitalPresenceFilter = req.body.digitalPresenceFilter;
    let technologyFilter = req.body.technologyFilter;
    let restrictTechnologyFilter = req.body.restrictTechnologyFilter


    let twitterData = { count: 0, id: [] },
        facebookData = { count: 0, id: [] },
        linkedInData = { count: 0, id: [] },
        instagramData = { count: 0, id: [] },
        youtubeData = { count: 0, id: [] },
        websiteData = { count: 0, id: [] };

    let totalCount = 0

    let whereFilter = [{ dataset }];

    if (file_name !== "Master DB (Golden Source)") whereFilter.push({ file_name });

    frimographicFilter && frimographicFilter.industry && whereFilter.push({ industry: { [Op.or]: frimographicFilter.industry } })
    frimographicFilter && frimographicFilter.main_hq_location && whereFilter.push({ main_hq_location: { [Op.or]: frimographicFilter.main_hq_location } })
    frimographicFilter && frimographicFilter.emp_size && whereFilter.push({ total_personnel: { [Op.or]: frimographicFilter.emp_size } })
    frimographicFilter && frimographicFilter.total_personnel && whereFilter.push({ company_name: { [Op.or]: frimographicFilter.total_personnel } })

    if (digitalPresenceFilter && digitalPresenceFilter.websites) {
        if (digitalPresenceFilter.websites.indexOf('Has') > -1) digitalPresenceFilter.websites.push({ [Op.ne]: null })
        whereFilter.push({ website: { [Op.or]: digitalPresenceFilter.websites } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.email) {
        if (digitalPresenceFilter.email.indexOf('Has') > -1) digitalPresenceFilter.email.push({ [Op.ne]: null })
        whereFilter.push({ company_email_address: { [Op.or]: digitalPresenceFilter.email } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.phone) {
        if (digitalPresenceFilter.phone.indexOf('Has') > -1) digitalPresenceFilter.phone.push({ [Op.ne]: null })
        whereFilter.push({ main_line_number: { [Op.or]: digitalPresenceFilter.phone } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.twitter) {
        if (digitalPresenceFilter.twitter.indexOf('Has') > -1) digitalPresenceFilter.twitter.push({ [Op.ne]: null })
        whereFilter.push({ twitter: { [Op.or]: digitalPresenceFilter.twitter } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.linkedIn) {
        if (digitalPresenceFilter.linkedIn.indexOf('Has') > -1) digitalPresenceFilter.linkedIn.push({ [Op.ne]: null })
        whereFilter.push({ linkedIn: { [Op.or]: digitalPresenceFilter.linkedIn } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.instagram) {
        if (digitalPresenceFilter.instagram.indexOf('Has') > -1) digitalPresenceFilter.instagram.push({ [Op.ne]: null })
        whereFilter.push({ instagram: { [Op.or]: digitalPresenceFilter.instagram } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.facebook) {
        if (digitalPresenceFilter.facebook.indexOf('Has') > -1) digitalPresenceFilter.facebook.push({ [Op.ne]: null })
        whereFilter.push({ facebook: { [Op.or]: digitalPresenceFilter.facebook } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.address) {
        if (digitalPresenceFilter.address.indexOf('Has') > -1) digitalPresenceFilter.address.push({ [Op.ne]: null })
        whereFilter.push({ address: { [Op.or]: digitalPresenceFilter.address } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.digital) {
        if (digitalPresenceFilter.digital.indexOf('Basic') > -1) digitalPresenceFilter.digital.push({ [Op.lt]: 2 })
        if (digitalPresenceFilter.digital.indexOf('Intermediate') > -1) digitalPresenceFilter.digital.push({ [Op.and]: [{ [Op.gte]: 2 }, { [Op.lt]: 5 }] })
        if (digitalPresenceFilter.digital.indexOf('High') > -1) digitalPresenceFilter.digital.push({ [Op.and]: [{ [Op.gte]: 5 }, { [Op.lt]: 8 }] })
        if (digitalPresenceFilter.digital.indexOf('Advance') > -1) digitalPresenceFilter.digital.push({ [Op.gte]: 8 })
        whereFilter.push({ overall_knapshot_score: { [Op.or]: digitalPresenceFilter.digital } })
    }
    let results = [], obj = {}, digitalAssetsObj = {}, allProvider = [], digitalAssets = []

    try {
        const companies = await Company.findAll({
            where: {
                [Op.and]: whereFilter
            },
            attributes: ["id", "industry", "company_name", "asset"],
            include: [
                { model: Directory }
            ]
        }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter))
        // .then(COMP => {
        //     return COMP.map(x => {
        //         let { asset } = x.dataValues
        //         let assets = JSON.parse(asset)


        //         let total = {}
        //         if (assets) for (var category in assets) {
        //             if (!assets.hasOwnProperty(category)) continue;
        //             if (!keyValues[category]) continue;

        //             var types = assets[category];
        //             for (var type in types) {
        //                 if (!types.hasOwnProperty(type)) continue;
        //                 if (!keyValues[category].includes(type)) continue;


        //                 var brands = [...new Set(types[type])];
        //                 for (var j = 0; j < brands.length; j++) {
        //                     var brand = brands[j];

        //                     total[category] = total[category] ? total[category] : {};

        //                     var total_type = total[category];
        //                     total_type[type] = total_type[type] ? total_type[type] : [];

        //                     total[category][type].push(brand)
        //                 }
        //             }
        //         }

        //         // data change
        //         x.dataValues.asset = JSON.stringify(total);
        //         return x;

        //     })
        // }).filter(value => {
        //     let assets = JSON.parse(value.dataValues.asset);

        //     if (!(technologyFilter && Object.keys(technologyFilter).length)) return true
        //     if (assets) {
        //         var technologyFilterIterator = ThreeLevelIterator(technologyFilter);
        //         var pass = true;
        //         for (var row of technologyFilterIterator) {
        //             var { f_key, s_key, t_key } = row;
        //             if (assets[f_key] && assets[f_key][s_key] && assets[f_key][s_key].includes(t_key)) {

        //             }
        //             else {
        //                 pass = false;
        //                 break;
        //             }
        //         }
        //         return pass;
        //     }
        //     return true
        // });
        // I am here
        await Company.findAll({
            where: {
                [Op.and]: whereFilter
            },
            attributes: ["id", "facebook", "twitter", "linkedIn", "instagram", "website", "youtube", "industry", "asset"],
            include: [
                { model: Directory }
            ]
        }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter))
            // .then(COMP => {
            //     return COMP.map(x => {
            //         let { asset } = x.dataValues
            //         let assets = JSON.parse(asset)


            //         let total = {}
            //         if (assets) for (var category in assets) {
            //             if (!assets.hasOwnProperty(category)) continue;
            //             if (!keyValues[category]) continue;

            //             var types = assets[category];
            //             for (var type in types) {
            //                 if (!types.hasOwnProperty(type)) continue;
            //                 if (!keyValues[category].includes(type)) continue;


            //                 var brands = [...new Set(types[type])];
            //                 for (var j = 0; j < brands.length; j++) {
            //                     var brand = brands[j];

            //                     total[category] = total[category] ? total[category] : {};

            //                     var total_type = total[category];
            //                     total_type[type] = total_type[type] ? total_type[type] : [];

            //                     total[category][type].push(brand)
            //                 }
            //             }
            //         }

            //         // data change
            //         x.dataValues.asset = JSON.stringify(total);
            //         return x;

            //     })
            // }).filter(value => {
            //     let assets = JSON.parse(value.dataValues.asset);

            //     if (!(technologyFilter && Object.keys(technologyFilter).length)) return true
            //     if (assets) {
            //         var technologyFilterIterator = ThreeLevelIterator(technologyFilter);
            //         var pass = true;
            //         for (var row of technologyFilterIterator) {
            //             var { f_key, s_key, t_key } = row;
            //             if (assets[f_key] && assets[f_key][s_key] && assets[f_key][s_key].includes(t_key)) {

            //             }
            //             else {
            //                 pass = false;
            //                 break;
            //             }
            //         }
            //         return pass;
            //     }
            //     return true
            // })
            .then(COMP => {
                COMP.map(x => {
                    const { id, twitter, facebook, linkedIn, instagram, website, industry } = x.dataValues

                    if (!digitalAssetsObj[industry]) {
                        digitalAssetsObj[industry] = {
                            industries: {
                                Twitter: { count: 0, id: [] },
                                Facebook: { count: 0, id: [] },
                                LinkedIn: { count: 0, id: [] },
                                Instagram: { count: 0, id: [] },
                                Youtube: { count: 0, id: [] },
                                Website: { count: 0, id: [] }
                            },
                            count: 0
                        };
                    }

                    if (twitter) {
                        twitterData.count += 1
                        twitterData.id.push(id)
                        digitalAssetsObj[industry]["industries"].Facebook.count += 1
                        digitalAssetsObj[industry]["industries"].Facebook.id.push(id)
                        digitalAssetsObj[industry].count += 1
                    }
                    if (facebook) {
                        facebookData.count += 1
                        facebookData.id.push(id)
                        digitalAssetsObj[industry]["industries"].Twitter.count += 1
                        digitalAssetsObj[industry]["industries"].Twitter.id.push(id)
                        digitalAssetsObj[industry].count += 1
                    }
                    if (linkedIn) {
                        linkedInData.count += 1
                        linkedInData.id.push(id)
                        digitalAssetsObj[industry]["industries"].LinkedIn.count += 1
                        digitalAssetsObj[industry]["industries"].LinkedIn.id.push(id)
                        digitalAssetsObj[industry].count += 1
                    }
                    if (instagram) {
                        instagramData.count += 1
                        instagramData.id.push(id)
                        digitalAssetsObj[industry]["industries"].Instagram.count += 1
                        digitalAssetsObj[industry]["industries"].Instagram.id.push(id)
                        digitalAssetsObj[industry].count += 1
                    }
                    if (website) {
                        websiteData.count += 1
                        websiteData.id.push(id)
                        digitalAssetsObj[industry]["industries"].Website.count += 1
                        digitalAssetsObj[industry]["industries"].Website.id.push(id)
                        digitalAssetsObj[industry].count += 1
                    }
                    if (twitter || facebook || linkedIn || instagram || website) totalCount += 1
                })
            });

        var count = 0, BusinessDir = 0, MarketPlaceDir = 0, JobDir = 0, LocationDir = 0, Forums = 0, Blogger = 0
        var BusinessDirId = [], MarketPlaceDirId = [], JobDirId = [], LocationDirId = [], ForumsId = [], BloggerId = []
        const DirectoryNameArr = ["bloggers", "forum", "jobDirectory", "locationDirectory", "marketplace", "businessDirectory"]
        if (companies) {
            for (let i in companies) {
                let id = companies[i].id;
                let industry = companies[i].industry
                if (!industry) continue;
                let directories = companies[i].directories
                let directoryArr = [], linkArr = []
                let provider = []

                for (let j in directories) {
                    if (DirectoryNameArr.indexOf(directories[j].directory) > -1) {
                        directories[j] && directoryArr.push(directories[j].directory)
                        directories[j] && directories[j].link && linkArr.push(directories[j].link)
                    }
                }

                if (!obj[industry]) {
                    obj[industry] = {
                        industries: {
                            BusinessDir: { count: 0, id: [] },
                            Forums: { count: 0, id: [] },
                            JobDir: { count: 0, id: [] },
                            LocationDir: { count: 0, id: [] },
                            MarketPlaceDir: { count: 0, id: [] },
                            Blogger: { count: 0, id: [] },
                        },
                        count: 0
                    };
                }

                const namePair = (name) => {
                    if (name === "locationDirectory") return "LocationDir"
                    if (name === "marketplace") return "MarketPlaceDir"
                    if (name === "forum") return "Forums"
                    if (name === "jobDirectory") return "JobDir"
                    if (name === "bloggers") return "Blogger"
                    return name
                }

                for (let link in linkArr) {
                    if (!linkArr.hasOwnProperty(link)) continue
                    let hostname = linkArr[link].replace('http://', '').replace('https://', '').replace('www.', '').split(/[/?#]/)[0];
                    provider.push({ label: hostname, key: namePair(directoryArr[link]), id: id })
                }

                allProvider.push(...provider)

                if (directoryArr.indexOf('forum') > -1) {
                    obj[industry]["industries"].Forums.count += 1
                    obj[industry]["industries"].Forums.id.push(id)
                    obj[industry].count += 1
                    ForumsId.push(id)
                    Forums += 1
                    count += 1
                }
                if (directoryArr.indexOf('jobDirectory') > -1) {
                    obj[industry]["industries"].JobDir.count += 1
                    obj[industry]["industries"].JobDir.id.push(id)
                    obj[industry].count += 1
                    JobDirId.push(id)
                    JobDir += 1
                    count += 1
                }
                if (directoryArr.indexOf('locationDirectory') > -1) {
                    obj[industry]["industries"].LocationDir.count += 1
                    obj[industry]["industries"].LocationDir.id.push(id)
                    obj[industry].count += 1
                    LocationDirId.push(id)
                    LocationDir += 1
                    count += 1
                }
                if (directoryArr.indexOf('marketplace') > -1) {
                    obj[industry]["industries"].MarketPlaceDir.count += 1
                    obj[industry]["industries"].MarketPlaceDir.id.push(id)
                    obj[industry].count += 1
                    MarketPlaceDirId.push(id)
                    MarketPlaceDir += 1
                    count += 1
                }
                if (directoryArr.indexOf('businessDirectory') > -1) {
                    obj[industry]["industries"].BusinessDir.count += 1
                    obj[industry]["industries"].BusinessDir.id.push(id)
                    obj[industry].count += 1
                    BusinessDirId.push(id)
                    BusinessDir += 1
                    count += 1
                }
                if (directoryArr.indexOf('bloggers') > -1) {
                    obj[industry]["industries"].Blogger.count += 1
                    obj[industry]["industries"].Blogger.id.push(id)
                    obj[industry].count += 1
                    BloggerId.push(id)
                    Blogger += 1
                    count += 1
                }
            }
        }

        results.push(
            { label: "Blogger", id: BloggerId, count: Blogger },
            { label: "BusinessDir", id: BusinessDirId, count: BusinessDir },
            { label: "Forums", id: ForumsId, count: Forums },
            { label: "JobDir", id: JobDirId, count: JobDir },
            { label: "LocationDir", id: LocationDirId, count: LocationDir },
            { label: "MarketPlaceDir", id: MarketPlaceDirId, count: MarketPlaceDir },
            count
        );

        // let totalCount = websiteData.count + linkedInData.count + facebookData.count + youtubeData.count + twitterData.count + instagramData.count

        digitalAssets.push(
            { label: "Website", id: websiteData.id, count: websiteData.count },
            { label: "LinkedIn", id: linkedInData.id, count: linkedInData.count },
            { label: "Facebook", id: facebookData.id, count: facebookData.count },
            { label: "Youtube", id: youtubeData.id, count: youtubeData.count },
            { label: "Instagram", id: instagramData.id, count: instagramData.count },
            { label: "Twitter", id: twitterData.id, count: twitterData.count },
            totalCount
        );

        const labelKeyCount = (arr) => {
            return [...arr.reduce((r, e) => {
                let k = `${e.label}}|${e.key}`;
                if (!r.has(k)) r.set(k, { label: e.label, key: e.key, id: [e.id], count: 1 })
                else {
                    r.get(k).count++
                    r.get(k).id.push(e.id)
                }
                return r;
            }, new Map).values()]
        }

        const convert = (arr) => {
            var result = {};
            for (var i = 0; i < arr.length; i++) {
                if (!result[arr[i].key]) result[arr[i].key] = {
                    label: [arr[i].label],
                    id: [arr[i].id],
                    count: [arr[i].count],
                    totalCount: arr[i].count
                }
                else {
                    result[arr[i].key].label.push(arr[i].label),
                        result[arr[i].key].id.push(arr[i].id),
                        result[arr[i].key].count.push(arr[i].count),
                        result[arr[i].key].totalCount += arr[i].count
                }
            }
            return result
        }

        return res.status(200).json({
            message: "Successful",
            data: obj,
            digitalAssetsData: digitalAssetsObj,
            digitalAssets: digitalAssets,
            companies: companies,
            results: results,
            provider: convert(labelKeyCount(allProvider).sort((a, b) => b.count - a.count)),
            // dirArr: directoryArr,
            // count: companies.length
        });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.getDigitalFootprint = async function (req, res) {

    const dataset = req.body.dataset;
    const digitals = req.body.digitals;
    const file_name = req.body.file_name;

    let frimographicFilter = req.body.frimographicFilter;
    let digitalPresenceFilter = req.body.digitalPresenceFilter;
    const technologyFilter = req.body.technologyFilter
    const restrictTechnologyFilter = req.body.restrictTechnologyFilter

    let whereFilter = [{ dataset }];

    if (file_name !== "Master DB (Golden Source)") whereFilter.push({ file_name });

    frimographicFilter && frimographicFilter.industry && whereFilter.push({ industry: { [Op.or]: frimographicFilter.industry } })
    frimographicFilter && frimographicFilter.main_hq_location && whereFilter.push({ main_hq_location: { [Op.or]: frimographicFilter.main_hq_location } })
    frimographicFilter && frimographicFilter.emp_size && whereFilter.push({ total_personnel: { [Op.or]: frimographicFilter.emp_size } })
    frimographicFilter && frimographicFilter.total_personnel && whereFilter.push({ company_name: { [Op.or]: frimographicFilter.total_personnel } })

    if (digitalPresenceFilter && digitalPresenceFilter.websites) {
        if (digitalPresenceFilter.websites.indexOf('Has') > -1) digitalPresenceFilter.websites.push({ [Op.ne]: null })
        whereFilter.push({ website: { [Op.or]: digitalPresenceFilter.websites } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.email) {
        if (digitalPresenceFilter.email.indexOf('Has') > -1) digitalPresenceFilter.email.push({ [Op.ne]: null })
        whereFilter.push({ company_email_address: { [Op.or]: digitalPresenceFilter.email } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.phone) {
        if (digitalPresenceFilter.phone.indexOf('Has') > -1) digitalPresenceFilter.phone.push({ [Op.ne]: null })
        whereFilter.push({ main_line_number: { [Op.or]: digitalPresenceFilter.phone } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.twitter) {
        if (digitalPresenceFilter.twitter.indexOf('Has') > -1) digitalPresenceFilter.twitter.push({ [Op.ne]: null })
        whereFilter.push({ twitter: { [Op.or]: digitalPresenceFilter.twitter } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.linkedIn) {
        if (digitalPresenceFilter.linkedIn.indexOf('Has') > -1) digitalPresenceFilter.linkedIn.push({ [Op.ne]: null })
        whereFilter.push({ linkedIn: { [Op.or]: digitalPresenceFilter.linkedIn } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.instagram) {
        if (digitalPresenceFilter.instagram.indexOf('Has') > -1) digitalPresenceFilter.instagram.push({ [Op.ne]: null })
        whereFilter.push({ instagram: { [Op.or]: digitalPresenceFilter.instagram } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.facebook) {
        if (digitalPresenceFilter.facebook.indexOf('Has') > -1) digitalPresenceFilter.facebook.push({ [Op.ne]: null })
        whereFilter.push({ facebook: { [Op.or]: digitalPresenceFilter.facebook } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.address) {
        if (digitalPresenceFilter.address.indexOf('Has') > -1) digitalPresenceFilter.address.push({ [Op.ne]: null })
        whereFilter.push({ address: { [Op.or]: digitalPresenceFilter.address } })
    }
    // if (digitalPresenceFilter && digitalPresenceFilter.directory) {
    //     if (digitalPresenceFilter.directory.indexOf('0 Presence') > -1) digitalPresenceFilter.directory.push({ [Op.eq]: -1 })
    //     if (digitalPresenceFilter.directory.indexOf('intermediate') > -1) digitalPresenceFilter.directory.push({ [Op.and]: [{ [Op.gte]: 2 }, { [Op.lt]: 5 }] })
    //     if (digitalPresenceFilter.directory.indexOf('high') > -1) digitalPresenceFilter.directory.push({ [Op.and]: [{ [Op.gte]: 5 }, { [Op.lt]: 8 }] })
    //     if (digitalPresenceFilter.directory.indexOf('advance') > -1) digitalPresenceFilter.directory.push({ [Op.gte]: 8 })
    //     whereFilter.push({ no_of_directory_presence: { [Op.or]: digitalPresenceFilter.directory } })
    // }
    if (digitalPresenceFilter && digitalPresenceFilter.digital) {
        if (digitalPresenceFilter.digital.indexOf('Basic') > -1) digitalPresenceFilter.digital.push({ [Op.lt]: 2 })
        if (digitalPresenceFilter.digital.indexOf('Intermediate') > -1) digitalPresenceFilter.digital.push({ [Op.and]: [{ [Op.gte]: 2 }, { [Op.lt]: 5 }] })
        if (digitalPresenceFilter.digital.indexOf('High') > -1) digitalPresenceFilter.digital.push({ [Op.and]: [{ [Op.gte]: 5 }, { [Op.lt]: 8 }] })
        if (digitalPresenceFilter.digital.indexOf('Advance') > -1) digitalPresenceFilter.digital.push({ [Op.gte]: 8 })
        whereFilter.push({ overall_knapshot_score: { [Op.or]: digitalPresenceFilter.digital } })
    }

    let results = [];

    let data = {
        Basic: {
            label: "Basic",
            backgroundColor: '#000000',
            radius: 3.5,
            pointBorderWidth: 0,
            scaleOverride: true,
            scaleSteps: 1,
            scaleStartValue: -1,
            data: []
        },
        Intermediate: {
            label: "Intermediate",
            backgroundColor: '#70AD47',
            radius: 3.5,
            pointBorderWidth: 0,
            scaleOverride: true,
            scaleSteps: 1,
            scaleStartValue: -1,
            data: []
        },
        High: {
            label: "High",
            backgroundColor: '#03B1F1',
            radius: 3.5,
            pointBorderWidth: 0,
            scaleOverride: true,
            scaleSteps: 1,
            scaleStartValue: -1,
            data: []
        },
        Advanced: {
            label: "Advanced",
            backgroundColor: '#4472C5',
            radius: 3.5,
            pointBorderWidth: 0,
            scaleOverride: true,
            scaleSteps: 1,
            scaleStartValue: -1,
            data: []
        },
    }

    let query = {
        Basic: [
            { dataset: dataset },
            { overall_knapshot_score: { [Op.lt]: 2.0 } }
        ],
        Intermediate: [
            { dataset: dataset },
            { overall_knapshot_score: { [Op.gte]: 2.0 } },
            { overall_knapshot_score: { [Op.lt]: 5.0 } }
        ],
        High: [
            { dataset: dataset },
            { overall_knapshot_score: { [Op.gte]: 5.0 } },
            { overall_knapshot_score: { [Op.lt]: 8.0 } }
        ],
        Advanced: [
            { dataset: dataset },
            { overall_knapshot_score: { [Op.gte]: 8.0 } },
        ]
    }

    // if (filename !== "Master DB (Golden Source)") {
    query["Basic"].push(...whereFilter);
    query["Intermediate"].push(...whereFilter);
    query["High"].push(...whereFilter);
    query["Advanced"].push(...whereFilter);
    // }

    try {
        let allCompanies = [];

        if (digitals.indexOf("Basic") >= 0) {
            let companies = await Company.findAll({
                where: { [Op.and]: query["Basic"] },
                include: [
                    { model: Directory }
                ]
            }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter))

            allCompanies.push(...companies);
        }

        if (digitals.indexOf("Intermediate") >= 0) {
            let companies = await Company.findAll({
                where: { [Op.and]: query["Intermediate"] },
                include: [
                    { model: Directory }
                ]
            }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter))
            allCompanies.push(...companies);
        }

        if (digitals.indexOf("High") >= 0) {
            let companies = await Company.findAll({
                where: { [Op.and]: query["High"] },
                include: [
                    { model: Directory }
                ]
            }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter))
            allCompanies.push(...companies);
        }

        if (digitals.indexOf("Advanced") >= 0) {
            let companies = await Company.findAll({
                where: { [Op.and]: query["Advanced"] },
                include: [
                    { model: Directory }
                ]
            }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter))
            allCompanies.push(...companies);
        }

        if (allCompanies) {
            for (let i = 0; i < allCompanies.length; i++) {

                let company_name = allCompanies[i].company_name;
                let company_id = allCompanies[i].id;
                let digitalValue = 0;
                let assetValue = 0;

                if (allCompanies[i].website !== "" && allCompanies[i].website !== null && allCompanies[i].website !== "cannot verify") {
                    digitalValue += 1.2;
                }
                if (allCompanies[i].linkedIn !== "" && allCompanies[i].linkedIn !== null && allCompanies[i].linkedIn !== "cannot verify") {
                    digitalValue += 0.2;
                }
                if (allCompanies[i].facebook !== "" && allCompanies[i].facebook !== null && allCompanies[i].facebook !== "cannot verify") {
                    digitalValue += 0.2;
                }
                if (allCompanies[i].twitter !== "" && allCompanies[i].twitter !== null && allCompanies[i].twitter !== "cannot verify") {
                    digitalValue += 0.1;
                }
                if (allCompanies[i].instagram !== "" && allCompanies[i].instagram !== null && allCompanies[i].instagram !== "cannot verify") {
                    digitalValue += 0.1;
                }
                if (allCompanies[i].company_email_address !== "" && allCompanies[i].company_email_address !== null && allCompanies[i].company_email_address !== "cannot verify") {
                    let mail = allCompanies[i].company_email_address.split('@')[1];
                    if (mail === 'gmail.com' || mail === 'yahoo.com') {
                        digitalValue += 0.2;
                    } else {
                        digitalValue += 0.4;
                    }
                }
                if (allCompanies[i].no_of_directory_presence !== "" && allCompanies[i].no_of_directory_presence !== null && allCompanies[i].no_of_directory_presence !== "cannot verify") {
                    if (allCompanies[i].no_of_directory_presence <= 2) digitalValue += 0.2;
                    if (allCompanies[i].no_of_directory_presence >= 3) digitalValue += 0.4;
                }
                if (allCompanies[i].address !== "" && allCompanies[i].address !== null && allCompanies[i].address !== "cannot verify") {
                    digitalValue += 0.2;
                }
                if (allCompanies[i].main_line_number !== "" && allCompanies[i].main_line_number !== null && allCompanies[i].main_line_number !== "cannot verify" && allCompanies[i].main_line_number !== "+normal") {
                    digitalValue += 0.2;
                }

                if (allCompanies[i].asset !== null) {
                    let assets = JSON.parse(allCompanies[i].asset);
                    if (assets["Advertising"] !== undefined) {
                        let len = 0;
                        Object.values(assets["Advertising"]).map(a => {
                            if (a && typeof a === "object" && a.length > 0) {
                                a.map(b => {
                                    if (len < 1.4) {
                                        len += 0.1
                                    }
                                })
                            }
                        })
                        assetValue += len;
                    }
                    if (assets["Analytics and Tracking"] !== undefined) {
                        let len = 0;
                        Object.values(assets["Analytics and Tracking"]).map(a => {
                            if (a && typeof a === "object" && a.length > 0) {
                                a.map(b => {
                                    if (len < 1.4) {
                                        len += 0.1
                                    }
                                })
                            }
                        })
                        assetValue += len;
                    }
                    if (assets["Ecommerce"] !== undefined) {
                        let len = 0;
                        Object.values(assets["Ecommerce"]).map(a => {
                            if (a && typeof a === "object" && a.length > 0) {
                                a.map(b => {
                                    if (len < 1.4) {
                                        len += 0.1
                                    }
                                })
                            }
                        })
                        assetValue += len;
                    }
                    if (assets["Payment"] !== undefined) {
                        let len = 0;
                        Object.values(assets["Payment"]).map(a => {
                            if (a && typeof a === "object" && a.length > 0) {
                                a.map(b => {
                                    if (len < 1.4) {
                                        len += 0.1
                                    }
                                })
                            }
                        })
                        assetValue += len;
                    }
                    if (assets["Widgets"] !== undefined) {
                        let len = 0;
                        Object.values(assets["Widgets"]).map(a => {
                            if (a && typeof a === "object" && a.length > 0) {
                                a.map(b => {
                                    if (len < 0.6) {
                                        len += 0.1
                                    }
                                })
                            }
                        })
                        assetValue += len;
                    }
                    if (assets["Content Management System"] !== undefined) {
                        let len = 0;
                        Object.values(assets["Content Management System"]).map(a => {
                            if (a && typeof a === "object" && a.length > 0) {
                                a.map(b => {
                                    if (len < 0.4) {
                                        len += 0.1
                                    }
                                })
                            }
                        })
                        assetValue += len;
                    }
                }

                let total = assetValue + digitalValue;

                let xValue = parseFloat(assetValue.toFixed(1));
                let yValue = parseFloat(digitalValue.toFixed(1));

                if (total < 2 && digitals.indexOf("Basic") >= 0) {
                    data["Basic"]["data"].push({ x: xValue, y: yValue, company_name: company_name, company_id: company_id });
                } else if (total >= 2 && total < 5 && digitals.indexOf("Intermediate") >= 0) {
                    data["Intermediate"]["data"].push({ x: xValue, y: yValue, company_name: company_name, company_id: company_id });
                } else if (total >= 5 && total < 8 && digitals.indexOf("High") >= 0) {
                    data["High"]["data"].push({ x: xValue, y: yValue, company_name: company_name, company_id: company_id });
                } else if (total >= 8 && digitals.indexOf("Advanced") >= 0) {
                    data["Advanced"]["data"].push({ x: xValue, y: yValue, company_name: company_name, company_id: company_id });
                }
            }
        }
        return res.status(200).json({ message: "OK", results: Object.values(data) });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.totalTechnologySelect = async function (req, res) {

    const file_name = req.body.file_name;
    const dataset = req.body.dataset;
    const frimographicFilter = req.body.frimographicFilter;
    const digitalPresenceFilter = req.body.digitalPresenceFilter

    let whereFilter = [
        { dataset },
        // { asset: { [Op.ne]: null } }
    ];

    if (file_name !== "Master DB (Golden Source)") whereFilter.push({ file_name });

    frimographicFilter && frimographicFilter.industry && whereFilter.push({ industry: { [Op.or]: frimographicFilter.industry } })
    frimographicFilter && frimographicFilter.main_hq_location && whereFilter.push({ main_hq_location: { [Op.or]: frimographicFilter.main_hq_location } })
    frimographicFilter && frimographicFilter.emp_size && whereFilter.push({ total_personnel: { [Op.or]: frimographicFilter.emp_size } })
    frimographicFilter && frimographicFilter.total_personnel && whereFilter.push({ company_name: { [Op.or]: frimographicFilter.total_personnel } })

    if (digitalPresenceFilter && digitalPresenceFilter.websites) {
        if (digitalPresenceFilter.websites.indexOf('Has') > -1) digitalPresenceFilter.websites.push({ [Op.ne]: null })
        whereFilter.push({ website: { [Op.or]: digitalPresenceFilter.websites } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.email) {
        if (digitalPresenceFilter.email.indexOf('Has') > -1) digitalPresenceFilter.email.push({ [Op.ne]: null })
        whereFilter.push({ company_email_address: { [Op.or]: digitalPresenceFilter.email } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.phone) {
        if (digitalPresenceFilter.phone.indexOf('Has') > -1) digitalPresenceFilter.phone.push({ [Op.ne]: null })
        whereFilter.push({ main_line_number: { [Op.or]: digitalPresenceFilter.phone } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.twitter) {
        if (digitalPresenceFilter.twitter.indexOf('Has') > -1) digitalPresenceFilter.twitter.push({ [Op.ne]: null })
        whereFilter.push({ twitter: { [Op.or]: digitalPresenceFilter.twitter } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.linkedIn) {
        if (digitalPresenceFilter.linkedIn.indexOf('Has') > -1) digitalPresenceFilter.linkedIn.push({ [Op.ne]: null })
        whereFilter.push({ linkedIn: { [Op.or]: digitalPresenceFilter.linkedIn } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.instagram) {
        if (digitalPresenceFilter.instagram.indexOf('Has') > -1) digitalPresenceFilter.instagram.push({ [Op.ne]: null })
        whereFilter.push({ instagram: { [Op.or]: digitalPresenceFilter.instagram } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.facebook) {
        if (digitalPresenceFilter.facebook.indexOf('Has') > -1) digitalPresenceFilter.facebook.push({ [Op.ne]: null })
        whereFilter.push({ facebook: { [Op.or]: digitalPresenceFilter.facebook } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.address) {
        if (digitalPresenceFilter.address.indexOf('Has') > -1) digitalPresenceFilter.address.push({ [Op.ne]: null })
        whereFilter.push({ address: { [Op.or]: digitalPresenceFilter.address } })
    }
    // if (digitalPresenceFilter && digitalPresenceFilter.directory) {
    //     if (digitalPresenceFilter.directory.indexOf('0 Presence') > -1) digitalPresenceFilter.directory.push({ [Op.eq]: -1 })
    //     if (digitalPresenceFilter.directory.indexOf('intermediate') > -1) digitalPresenceFilter.directory.push({ [Op.and]: [{ [Op.gte]: 2 }, { [Op.lt]: 5 }] })
    //     if (digitalPresenceFilter.directory.indexOf('high') > -1) digitalPresenceFilter.directory.push({ [Op.and]: [{ [Op.gte]: 5 }, { [Op.lt]: 8 }] })
    //     if (digitalPresenceFilter.directory.indexOf('advance') > -1) digitalPresenceFilter.directory.push({ [Op.gte]: 8 })
    //     whereFilter.push({ no_of_directory_presence: { [Op.or]: digitalPresenceFilter.directory } })
    // }
    if (digitalPresenceFilter && digitalPresenceFilter.digital) {
        if (digitalPresenceFilter.digital.indexOf('Basic') > -1) digitalPresenceFilter.digital.push({ [Op.lt]: 2 })
        if (digitalPresenceFilter.digital.indexOf('Intermediate') > -1) digitalPresenceFilter.digital.push({ [Op.and]: [{ [Op.gte]: 2 }, { [Op.lt]: 5 }] })
        if (digitalPresenceFilter.digital.indexOf('High') > -1) digitalPresenceFilter.digital.push({ [Op.and]: [{ [Op.gte]: 5 }, { [Op.lt]: 8 }] })
        if (digitalPresenceFilter.digital.indexOf('Advance') > -1) digitalPresenceFilter.digital.push({ [Op.gte]: 8 })
        whereFilter.push({ overall_knapshot_score: { [Op.or]: digitalPresenceFilter.digital } })
    }

    let total = {}, sortedTotal = {}, idArr = [], add = 0;

    try {

        const companies = await Company.findAll({
            where: { [Op.and]: whereFilter },
            attributes: ["asset", "id"]
        });

        if (companies) {
            for (let i = 0; i < companies.length; i++) {
                let id = companies[i]["id"];
                // idArr.push(id)
                if (companies[i]["asset"]) {

                    let assets = JSON.parse(companies[i]["asset"]);
                    // if(Object.keys(assets).length === 0) idArr.push(id)

                    for (let [categoryKey, categoryValue] of Object.entries(assets)) {

                        if (!keyValues[categoryKey]) continue;
                        for (let [typeKey, typeValue] of Object.entries(categoryValue)) {

                            if (!keyValues[categoryKey].includes(typeKey)) continue;
                            let brands = [...new Set(typeValue)];
                            for (let j = 0; j < brands.length; j++) {
                                add++
                                let brand = brands[j]
                                total[categoryKey] = total[categoryKey] ? total[categoryKey] : {};

                                var total_type = total[categoryKey];
                                total_type[typeKey] = total_type[typeKey] ? total_type[typeKey] : {};

                                var total_brand = total_type[typeKey];

                                if (!total_brand[brand]) {
                                    total_brand[brand] = 0
                                }
                                total_brand[brand]++
                            }
                        }
                    }

                    if (!add) idArr.push(id)
                    add = 0

                    // for (var category in assets) {
                    //     if (!assets.hasOwnProperty(category)) continue;
                    //     if (!keyValues[category]) continue;

                    //     var types = assets[category];
                    //     for (var type in types) {
                    //         if (!types.hasOwnProperty(type)) continue;
                    //         if (!keyValues[category].includes(type)) continue;


                    //         var brands = [...new Set(types[type])];
                    //         for (var j = 0; j < brands.length; j++) {
                    //             var brand = brands[j];

                    //             total[category] = total[category] ? total[category] : {};

                    //             var total_type = total[category];
                    //             total_type[type] = total_type[type] ? total_type[type] : {};

                    //             var total_brand = total_type[type];
                    //             total_brand[brand] = total_brand[brand] ? total_brand[brand] + 1 : 1;

                    //         }
                    //     }
                    // }
                }
                else idArr.push(id)
            }

            // console.log("before", Object.keys(total).length)
            let clone = AssetDP(total)
            // console.log("after", Object.keys(clone).length)

            Object.keys(clone).map(category => {
                Object.keys(clone[category]).map(type => {
                    let obj = clone[category][type];

                    // // Get an array of the keys:
                    let keys = Object.keys(obj);

                    // // Then sort by using the keys to lookup the values in the original object:
                    keys.sort(function (a, b) { return obj[b] - obj[a] });
                    keys.map(brands => {

                        !sortedTotal[category] && (sortedTotal[category] = {});
                        !sortedTotal[category][type] && (sortedTotal[category][type] = {});
                        sortedTotal[category][type][brands] = obj[brands];
                    })
                })
            })


            return res.status(200).json({
                message: "Successful",
                data: sortedTotal,
                idArr: [...new Set(idArr)]
            })
        }
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}

exports.totalTechnology = async function (req, res) {

    const file_name = req.body.file_name;
    const dataset = req.body.dataset;
    const frimographicFilter = req.body.frimographicFilter;
    const digitalPresenceFilter = req.body.digitalPresenceFilter
    const technologyFilter = req.body.technologyFilter
    const restrictTechnologyFilter = req.body.restrictTechnologyFilter

    let whereFilter = [{ dataset }, { asset: { [Op.ne]: null } }];

    if (file_name !== "Master DB (Golden Source)") whereFilter.push({ file_name });

    frimographicFilter && frimographicFilter.industry && whereFilter.push({ industry: { [Op.or]: frimographicFilter.industry } })
    frimographicFilter && frimographicFilter.main_hq_location && whereFilter.push({ main_hq_location: { [Op.or]: frimographicFilter.main_hq_location } })
    frimographicFilter && frimographicFilter.emp_size && whereFilter.push({ total_personnel: { [Op.or]: frimographicFilter.emp_size } })
    frimographicFilter && frimographicFilter.total_personnel && whereFilter.push({ company_name: { [Op.or]: frimographicFilter.total_personnel } })

    if (digitalPresenceFilter && digitalPresenceFilter.websites) {
        if (digitalPresenceFilter.websites.indexOf('Has') > -1) digitalPresenceFilter.websites.push({ [Op.ne]: null })
        whereFilter.push({ website: { [Op.or]: digitalPresenceFilter.websites } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.email) {
        if (digitalPresenceFilter.email.indexOf('Has') > -1) digitalPresenceFilter.email.push({ [Op.ne]: null })
        whereFilter.push({ company_email_address: { [Op.or]: digitalPresenceFilter.email } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.phone) {
        if (digitalPresenceFilter.phone.indexOf('Has') > -1) digitalPresenceFilter.phone.push({ [Op.ne]: null })
        whereFilter.push({ main_line_number: { [Op.or]: digitalPresenceFilter.phone } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.twitter) {
        if (digitalPresenceFilter.twitter.indexOf('Has') > -1) digitalPresenceFilter.twitter.push({ [Op.ne]: null })
        whereFilter.push({ twitter: { [Op.or]: digitalPresenceFilter.twitter } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.linkedIn) {
        if (digitalPresenceFilter.linkedIn.indexOf('Has') > -1) digitalPresenceFilter.linkedIn.push({ [Op.ne]: null })
        whereFilter.push({ linkedIn: { [Op.or]: digitalPresenceFilter.linkedIn } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.instagram) {
        if (digitalPresenceFilter.instagram.indexOf('Has') > -1) digitalPresenceFilter.instagram.push({ [Op.ne]: null })
        whereFilter.push({ instagram: { [Op.or]: digitalPresenceFilter.instagram } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.facebook) {
        if (digitalPresenceFilter.facebook.indexOf('Has') > -1) digitalPresenceFilter.facebook.push({ [Op.ne]: null })
        whereFilter.push({ facebook: { [Op.or]: digitalPresenceFilter.facebook } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.address) {
        if (digitalPresenceFilter.address.indexOf('Has') > -1) digitalPresenceFilter.address.push({ [Op.ne]: null })
        whereFilter.push({ address: { [Op.or]: digitalPresenceFilter.address } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.directory) {

        if (digitalPresenceFilter.directory.indexOf('0 Presence') > -1) digitalPresenceFilter.directory.push({ [Op.eq]: -1 })
        if (digitalPresenceFilter.directory.indexOf('intermediate') > -1) digitalPresenceFilter.directory.push({ [Op.and]: [{ [Op.gte]: 2 }, { [Op.lt]: 5 }] })
        if (digitalPresenceFilter.directory.indexOf('high') > -1) digitalPresenceFilter.directory.push({ [Op.and]: [{ [Op.gte]: 5 }, { [Op.lt]: 8 }] })
        if (digitalPresenceFilter.directory.indexOf('advance') > -1) digitalPresenceFilter.directory.push({ [Op.gte]: 8 })
        whereFilter.push({ no_of_directory_presence: { [Op.or]: digitalPresenceFilter.directory } })
    }
    if (digitalPresenceFilter && digitalPresenceFilter.digital) {
        if (digitalPresenceFilter.digital.indexOf('Basic') > -1) digitalPresenceFilter.digital.push({ [Op.lt]: 2 })
        if (digitalPresenceFilter.digital.indexOf('Intermediate') > -1) digitalPresenceFilter.digital.push({ [Op.and]: [{ [Op.gte]: 2 }, { [Op.lt]: 5 }] })
        if (digitalPresenceFilter.digital.indexOf('High') > -1) digitalPresenceFilter.digital.push({ [Op.and]: [{ [Op.gte]: 5 }, { [Op.lt]: 8 }] })
        if (digitalPresenceFilter.digital.indexOf('Advance') > -1) digitalPresenceFilter.digital.push({ [Op.gte]: 8 })
        whereFilter.push({ overall_knapshot_score: { [Op.or]: digitalPresenceFilter.digital } })
    }

    let obj = {}, industryArray = [], total = [], assets, loopCount = 0, outerLoop = 0, companyCount = 0, companyWithAsset = 0
    let add = 0, categoryName
    try {

        const companies = await Company.findAll({
            where: { [Op.and]: whereFilter },
            attributes: ["id", "asset", "industry"],
            include: [
                { model: Directory }
            ]
        }).then(COMP => filterFunction(COMP, technologyFilter, restrictTechnologyFilter, digitalPresenceFilter))

        if (companies) {
            for (let i = 0; i < companies.length; i++) {
                // companyCount++
                industryArray.push(companies[i].industry)
                if (companies[i]["asset"]) {

                    // companyWithAsset++
                    assets = JSON.parse(companies[i]["asset"]);

                    for (let [category, categoryValue] of Object.entries(assetDataProcess(assets))) {
                        // outerLoop++
                        for (let [type, brands] of Object.entries(categoryValue)) {
                            for (var j = 0; j < brands.length; j++) {
                                var brand = brands[j];
                                total.push({
                                    type,
                                    brand,
                                    id: companies[i].id
                                })

                                let id = companies[i].id;
                                if (keyValuesPair[category] && keyValuesPair[category].includes(type)) {
                                    // loopCount++
                                    categoryName = category
                                    if (obj[category] === undefined) {

                                        obj[category] = {
                                            type: category,
                                            count: 0,
                                            options: [
                                                {
                                                    label: type,
                                                    count: 1,
                                                    id: [id]
                                                }
                                            ],
                                            industries: [
                                                {
                                                    label: companies[i]["industry"],
                                                    key: type,
                                                    count: 1,
                                                    id: [id]
                                                }
                                            ]
                                        };
                                    } else {
                                        // obj[category]["count"] += 1;

                                        let isEqual = false;
                                        let industryEqual = false;

                                        obj[category]["options"].forEach(item => {
                                            if (item["label"] === type) {
                                                add++
                                                if (!item["id"].includes(id)) {
                                                    item["count"] += 1;
                                                    item["id"].push(id);
                                                }
                                                isEqual = true;
                                            }
                                        });

                                        obj[category]["industries"].forEach(item => {
                                            if (item["label"] === companies[i]["industry"] && item["key"] === type) {
                                                if (!item.id.includes(id)) {
                                                    item["count"] += 1;
                                                    item.id.push(id)
                                                }
                                                industryEqual = true;
                                            }
                                        });

                                        if (!isEqual) obj[category]["options"].push({ label: type, count: 1, id: [id] });
                                        if (!industryEqual) obj[category]["industries"].push({ label: companies[i]["industry"], key: type, count: 1, id: [id] });
                                    }
                                }
                            }
                        }
                        // if (keyValues[category]) obj[category]["count"] += 1;
                        if (categoryName && add) obj[categoryName]["count"] += 1;
                        add = 0, categoryName = null
                    }
                }
            }

            var output = [];

            total.forEach(function (item) {
                var existing = output.filter(function (v, i) {
                    return v.type == item.type;
                });
                if (existing.length) {
                    var existingIndex = output.indexOf(existing[0]);
                    output[existingIndex].brand = output[existingIndex].brand.concat(item.brand);
                    output[existingIndex].id = output[existingIndex].id.concat(item.id);
                } else {
                    if (typeof item.brand == 'string') {
                        item.id = [item.id]
                        item.brand = [item.brand];
                    }
                    output.push(item);
                }
            });

            let output2 = []

            let DupCount = (brands, Ids) => {

                let counts = {}, id = {};
                brands.forEach(myFunction)

                function myFunction(x, index) {
                    counts[x] = (counts[x] || 0) + 1;
                    if (Ids) {
                        if (!id[x]) id[x] = []
                        id[x].push(Ids[index])
                    }
                }

                // // Get an array of the keys:
                // let sortedObj = Object.keys(counts);

                // // Then sort by using the keys to lookup the values in the original object:
                // sortedObj.sort(function (a, b) { return obj[a] - obj[b] });


                var sortable = [];
                for (var brand in counts) {
                    sortable.push([brand, counts[brand]]);
                }

                sortable.sort((a, b) => b[1] - a[1]);

                function objectify(array) {
                    return array.reduce(function (p, c) {
                        p[c[0]] = c[1];
                        return p;
                    }, {});
                }

                if (Ids) return id
                return objectify(sortable)
            }

            for (var i in output) {
                if (output[i].brand) output2.push({
                    type: output[i].type,
                    brand: DupCount(output[i].brand),
                    count: output[i].brand.length,
                    id: DupCount(output[i].brand, output[i].id)
                })
            }

            industryArray = [...new Set(industryArray)]

            Object.values(obj).forEach((item, i) => {
                item.industryData = industryArray
                item.provider = output2

            })

            // console.log("loopCount", loopCount, "Outer", outerLoop, "Company With asset", companyWithAsset, "companyCount", companyCount)
            return res.status(200).json({ message: "Successful", data: Object.values(obj) })
        }
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}










